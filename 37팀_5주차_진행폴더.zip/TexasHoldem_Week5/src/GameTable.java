import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 서버에서만 실행하는 게임 규칙. 담당: 표신현
 * ServerMain은 synchronized(table) 안에서 사용한다.
 * 5주차: 올인, 사이드팟, 부족한 블라인드, 자동 카드 공개, 재시작을 추가했다.
 */
public final class GameTable {
    public static final int MAX_PLAYERS = 6;
    public static final int SMALL_BLIND = 10;
    public static final int BIG_BLIND = 20;
    public enum Phase { WAITING, PREFLOP, FLOP, TURN, RIVER, SHOWDOWN, FINISHED }
    public static final class Player {
        public final int id;
        public final String nickname;
        public int chips = 1000;
        public int bet;             // 이번 단계에서 낸 총액: 콜·레이즈 계산에 사용
        public int contribution;    // 이번 판에서 낸 총액: 사이드팟 계산에 사용
        public boolean connected = true;
        public boolean inHand;
        public boolean folded;
        private final List<Card> hand = new ArrayList<>();
        Player(int id, String nickname) { this.id = id; this.nickname = nickname; }
    }
    private final Map<Integer, Player> players = new LinkedHashMap<>();
    private final Set<Integer> pending = new LinkedHashSet<>();
    // 마지막으로 행동했을 때의 기준 베팅액. 짧은 올인 후 재레이즈 가능 여부에 사용한다.
    private final Map<Integer, Integer> lastActedBet = new LinkedHashMap<>();
    private final List<Card> board = new ArrayList<>();
    private final List<String> notices = new ArrayList<>();
    private int nextId = 1;
    private long revision, handNumber;
    private HandResult result = HandResult.empty();
    private Phase phase = Phase.WAITING;
    private int dealerId, smallBlindId, bigBlindId, turnId;
    private int pot, currentBet, minRaise = BIG_BLIND;
    private Deck deck;

    public Player addPlayer(String nickname) {
        if (!nickname.matches("[\\p{L}\\p{N}_]{1,12}")) {
            throw new IllegalArgumentException("닉네임은 공백 없는 문자·숫자·밑줄 1~12자로 입력하세요.");
        }
        if (players.size() >= MAX_PLAYERS) {
            throw new IllegalArgumentException("테이블이 가득 찼습니다. 퇴장한 자리는 판 종료 후 비워집니다.");
        }
        for (Player p : players.values()) {
            if (p.nickname.equalsIgnoreCase(nickname)) { throw new IllegalArgumentException("이미 사용 중인 닉네임입니다."); }
        }
        Player player = new Player(nextId++, nickname);
        players.put(player.id, player); revision++;
        notices.add(nickname + "님이 접속했습니다." + (isRunning() ? " 다음 판부터 참가합니다." : ""));
        return player;
    }
    public void removePlayer(int id) {
        Player p = players.get(id);
        if (p == null) { return; }
        p.connected = false;
        notices.add(p.nickname + "님이 나갔습니다.");
        if (getHostId() == 0) {
            players.clear(); clearTable();
        } else if (isRunning()) {
            // 올인은 연결이 끊겨도 쇼다운 자격을 유지한다.
            // 다른 퇴장자는 자기 차례에 체크/폴드한다. 차례 밖에서 즉시 폴드하지 않는다.
            // 이렇게 해야 사이드팟 참가자가 한꺼번에 없어지는 상황도 막을 수 있다.
            advanceAfter(id);
        }
        if (!isRunning()) { clearDeparted(); }
        revision++;
    }
    public void requireRevision(long received) {
        if (received != revision) {
            throw new IllegalStateException("화면 상태가 변경되었습니다. 현재 차례를 확인하고 다시 눌러 주세요.");
        }
    }
    public void startGame(int requesterId) {
        requireHost(requesterId);
        if (isRunning()) { throw new IllegalStateException("진행 중에는 다시 시작할 수 없습니다."); }
        long eligible = players.values().stream().filter(p -> p.connected && p.chips > 0).count();
        if (eligible < 2) { throw new IllegalStateException("칩이 남은 참가자가 두 명 필요합니다. 새 게임으로 초기화할 수 있습니다."); }
        result = HandResult.empty(); handNumber++;
        clearDeparted(); board.clear(); pending.clear(); lastActedBet.clear();
        pot = currentBet = turnId = 0; minRaise = BIG_BLIND; deck = new Deck();
        for (Player p : players.values()) {
            p.hand.clear(); p.bet = p.contribution = 0; p.folded = false;
            p.inHand = p.chips > 0;
        }
        List<Player> active = remaining();
        dealerId = nextAfter(dealerId, active);
        smallBlindId = active.size() == 2 ? dealerId : nextAfter(dealerId, active);
        bigBlindId = nextAfter(smallBlindId, active);
        int seat = dealerId;
        for (int round = 0; round < 2; round++) {
            for (int i = 0; i < active.size(); i++) {
                seat = nextAfter(seat, active); players.get(seat).hand.add(deck.draw());
            }
        }
        pay(players.get(smallBlindId), Math.min(SMALL_BLIND, players.get(smallBlindId).chips));
        pay(players.get(bigBlindId), Math.min(BIG_BLIND, players.get(bigBlindId).chips));
        currentBet = BIG_BLIND; phase = Phase.PREFLOP;
        for (Player p : actionable()) { pending.add(p.id); }
        notices.add("새 판 시작. 블라인드 10 / 20, 부족하면 가진 칩만 냅니다.");
        advanceAfter(bigBlindId);
        revision++;
    }
    /** 칩이 남은 사람이 한 명 이하인 게임 종료 상태에서 방장이 새 게임을 시작한다. */
    public void resetGame(int requesterId) {
        requireHost(requesterId);
        if (isRunning() || players.values().stream().filter(p -> p.connected && p.chips > 0).count() >= 2) {
            throw new IllegalStateException("칩이 남은 사람이 한 명 이하일 때 새 게임을 만들 수 있습니다.");
        }
        clearDeparted(); clearTable();
        for (Player p : players.values()) {
            p.chips = 1000; p.bet = p.contribution = 0; p.inHand = p.folded = false; p.hand.clear();
        }
        notices.add("새 게임: 모든 참가자의 칩을 1000개로 초기화했습니다. 방장이 게임 시작을 누르세요.");
        revision++;
    }
    private void requireHost(int id) {
        if (id != getHostId() || id == 0) { throw new IllegalStateException("방장만 실행할 수 있습니다."); }
    }
    private void clearTable() {
        board.clear(); pending.clear(); lastActedBet.clear();
        phase = Phase.WAITING; result = HandResult.empty();
        pot = currentBet = turnId = dealerId = smallBlindId = bigBlindId = 0; minRaise = BIG_BLIND;
    }
    public void act(int playerId, String action, int amount) {
        if (!isRunning() || playerId != turnId) { throw new IllegalStateException("현재 본인의 차례가 아닙니다."); }
        Player p = players.get(playerId);
        int toCall = currentBet - p.bet;
        switch (action) {
            case "CHECK" -> {
                if (toCall != 0) { throw new IllegalStateException("맞춰야 할 금액이 있어 체크할 수 없습니다."); }
                notices.add(p.nickname + ": 체크");
            }
            case "CALL" -> {
                if (toCall <= 0) { throw new IllegalStateException("콜할 금액이 없습니다. 체크하세요."); }
                int payment = Math.min(toCall, p.chips);
                pay(p, payment); notices.add(p.nickname + ": 콜 " + payment + (p.chips == 0 ? " (올인)" : ""));
            }
            case "BET", "RAISE" -> {
                if (action.equals("BET") != (currentBet == 0)) {
                    throw new IllegalStateException(currentBet == 0 ? "첫 베팅은 BET입니다." : "이미 베팅이 있어 RAISE를 사용하세요.");
                }
                raiseTo(p, amount);
            }
            case "ALLIN" -> {
                int total = p.bet + p.chips;
                if (total > currentBet) { raiseTo(p, total); }
                else {
                    int payment = p.chips; pay(p, payment);
                    notices.add(p.nickname + ": 올인 콜 " + payment);
                }
            }
            case "FOLD" -> { p.folded = true; notices.add(p.nickname + ": 폴드"); }
            default -> throw new IllegalArgumentException("지원하지 않는 행동입니다.");
        }
        lastActedBet.put(playerId, currentBet); pending.remove(playerId);
        turnId = 0; advanceAfter(playerId);
        if (!isRunning()) { clearDeparted(); }
        revision++;
    }
    private void raiseTo(Player p, int amount) {
        if (!canRaise(p)) { throw new IllegalStateException("이번 차례에는 추가 레이즈를 할 수 없습니다. 콜 또는 폴드하세요."); }
        int payment = amount - p.bet;
        if (amount <= currentBet || payment <= 0 || payment > p.chips) { throw new IllegalStateException("베팅 총액과 보유 칩을 확인하세요."); }
        int raiseSize = amount - currentBet;
        boolean fullRaise = raiseSize >= minRaise;
        if (!fullRaise && payment != p.chips) {
            throw new IllegalStateException("최소 총액 " + (currentBet + minRaise) + " 이상 또는 남은 칩 전부를 입력하세요.");
        }
        pay(p, payment); currentBet = amount;
        if (fullRaise) {
            minRaise = raiseSize; pending.clear();
            for (Player other : actionable()) { pending.add(other.id); }
        } else {
            // 짧은 올인은 콜할 금액만 올린다. 이전의 정상 레이즈 폭은 그대로 유지한다.
            for (Player other : actionable()) { if (other.bet < currentBet) { pending.add(other.id); } }
        }
        notices.add(p.nickname + ": 베팅 총액 " + amount + (p.chips == 0 ? " (올인)" : ""));
    }
    private boolean canRaise(Player p) {
        if (!isRunning() || !p.inHand || p.folded || p.chips == 0) { return false; }
        boolean opponentCanCall = remaining().stream().anyMatch(other -> other.id != p.id && other.chips > 0);
        Integer previous = lastActedBet.get(p.id);
        return opponentCanCall && (previous == null || currentBet - previous >= minRaise);
    }
    private void pay(Player p, int amount) {
        p.chips -= amount; p.bet += amount; p.contribution += amount; pot += amount;
    }
    /** 자동 진행을 반복한다. 결과를 기다릴 사람이 없으면 공용 카드가 끝까지 열린다. */
    private void advanceAfter(int lastId) {
        while (isRunning()) {
            List<Player> active = remaining(), actors = actionable();
            if (active.size() == 1) { settle(false); return; }
            pending.removeIf(id -> !actors.contains(players.get(id)));
            if (actors.size() <= 1) {
                // 혼자 남은 칩 보유자는 상대가 실제 낸 금액까지만 맞추면 된다.
                int highest = active.stream().mapToInt(p -> p.bet).max().orElse(0);
                currentBet = highest;
                if (actors.isEmpty() || actors.get(0).bet >= highest) { pending.clear(); }
            }
            if (pending.isEmpty()) {
                if (phase == Phase.RIVER) { settle(true); return; }
                nextStreet(); lastId = dealerId;
                continue;
            }
            if (turnId == 0 || !pending.contains(turnId)) {
                turnId = nextAfter(lastId, actors.stream().filter(p -> pending.contains(p.id)).toList());
            }
            Player next = players.get(turnId);
            if (next.connected) { return; }
            // 연결 종료는 차례가 왔을 때만 처리한다. 올인 참가자는 actors에 들어가지 않는다.
            if (next.bet < currentBet) { next.folded = true; notices.add(next.nickname + ": 연결 종료로 자동 폴드"); }
            else { lastActedBet.put(next.id, currentBet); notices.add(next.nickname + ": 연결 종료로 자동 체크"); }
            pending.remove(next.id); lastId = next.id; turnId = 0;
        }
    }
    private void nextStreet() {
        phase = switch (phase) {
            case PREFLOP -> Phase.FLOP;
            case FLOP -> Phase.TURN;
            case TURN -> Phase.RIVER;
            default -> throw new IllegalStateException("잘못된 게임 단계입니다.");
        };
        deck.draw(); // 공용 카드 공개 전 번 카드 한 장
        int count = phase == Phase.FLOP ? 3 : 1;
        for (int i = 0; i < count; i++) { board.add(deck.draw()); }
        currentBet = 0; minRaise = BIG_BLIND; turnId = 0;
        for (Player p : players.values()) { p.bet = 0; }
        pending.clear(); lastActedBet.clear();
        for (Player p : actionable()) { pending.add(p.id); }
        notices.add(GameState.phaseText(phase.name()) + ": 공용 카드 " + board.size() + "장 공개.");
    }
    private void settle(boolean showdown) {
        Map<Integer, HandEvaluator.Value> values = new LinkedHashMap<>();
        List<Player> active = remaining();
        if (showdown) {
            for (Player p : active) {
                List<Card> seven = new ArrayList<>(board); seven.addAll(p.hand);
                values.put(p.id, HandEvaluator.evaluate(seven));
            }
        }
        List<PotSettlement.Contribution> contributions = new ArrayList<>();
        for (Player p : players.values()) {
            contributions.add(new PotSettlement.Contribution(p.id, p.contribution,
                    p.inHand && !p.folded, values.get(p.id)));
        }
        PotSettlement.Settlement settlement = PotSettlement.calculate(contributions, dealerId);
        List<HandResult.Entry> entries = new ArrayList<>();
        for (Player p : active) {
            int award = settlement.awards().getOrDefault(p.id, 0), refund = settlement.refunds().getOrDefault(p.id, 0);
            p.chips += award + refund; // 서버가 이 위치에서 단 한 번 지급한다.
            HandEvaluator.Value value = values.get(p.id);
            entries.add(new HandResult.Entry(p.id, p.nickname, showdown ? value.category() : -1, award, refund,
                    showdown ? p.hand : List.of(), showdown ? value.cards() : List.of()));
        }
        result = new HandResult(handNumber, showdown ? "SHOWDOWN" : "FOLD", pot, entries, settlement.pots());
        pot = currentBet = turnId = 0; pending.clear(); lastActedBet.clear();
        for (Player p : players.values()) { p.bet = p.contribution = 0; }
        phase = showdown ? Phase.SHOWDOWN : Phase.FINISHED;
        notices.add("정산 완료. 판 결과 탭에서 팟별 수령액과 반환액을 확인하세요.");
    }
    private void clearDeparted() { players.values().removeIf(p -> !p.connected); }
    private List<Player> remaining() {
        return players.values().stream().filter(p -> p.inHand && !p.folded).toList();
    }
    private List<Player> actionable() { return remaining().stream().filter(p -> p.chips > 0).toList(); }
    private int nextAfter(int id, List<Player> candidates) {
        for (Player p : candidates) { if (p.id > id) { return p.id; } }
        return candidates.isEmpty() ? 0 : candidates.get(0).id;
    }
    public boolean isRunning() {
        return phase == Phase.PREFLOP || phase == Phase.FLOP || phase == Phase.TURN || phase == Phase.RIVER;
    }
    public int getHostId() {
        for (Player p : players.values()) { if (p.connected) { return p.id; } }
        return 0;
    }
    public List<Card> getHand(int id) {
        Player p = players.get(id); return p == null ? List.of() : new ArrayList<>(p.hand);
    }
    public HandResult getResult() { return result; }
    public GameState snapshot() {
        List<GameState.Seat> seats = new ArrayList<>();
        for (Player p : players.values()) {
            String status = !p.connected ? "LEFT" : p.folded ? "FOLD" : !p.inHand ? (p.chips == 0 ? "OUT" : "WAIT")
                    : isRunning() && p.chips == 0 ? "ALLIN" : !isRunning() && p.chips == 0 ? "OUT" : "PLAY";
            seats.add(new GameState.Seat(p.id, p.nickname, p.chips, p.bet, status, p.contribution, canRaise(p)));
        }
        return new GameState(revision, getHostId(), dealerId, smallBlindId, bigBlindId,
                phase.name(), turnId, pot, currentBet, minRaise, seats, board);
    }
    public List<String> drainNotices() {
        List<String> result = new ArrayList<>(notices); notices.clear(); return result;
    }
}
