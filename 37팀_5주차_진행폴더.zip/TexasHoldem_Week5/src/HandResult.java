import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** 한 판의 정산 결과와 통신 형식. 담당: 송준석, 게임 결과 연결: 표신현
 * 5주차: 팟별 지급 내역과 미매칭 금액 반환을 구분한다. 수신 시 칩을 다시 지급하지 않는다.
 */
public record HandResult(long handNumber, String type, int totalPot, List<Entry> entries, List<Pot> pots) {
    public record Entry(int id, String nickname, int category, int award, int refund,
            List<Card> hand, List<Card> bestFive) {
        public Entry { hand = List.copyOf(hand); bestFive = List.copyOf(bestFive); }
    }
    public record Pot(int amount, List<Integer> eligible, Map<Integer, Integer> payouts) {
        public Pot {
            eligible = List.copyOf(eligible);
            payouts = Collections.unmodifiableMap(new LinkedHashMap<>(payouts));
        }
    }
    public HandResult { entries = List.copyOf(entries); pots = List.copyOf(pots); }
    public static HandResult empty() { return new HandResult(0, "NONE", 0, List.of(), List.of()); }

    // 공백: 항목, 쉼표: 필드, 콜론: 목록, 등호: ID별 지급액. 닉네임에는 이 기호를 허용하지 않는다.
    public String toWire() {
        StringBuilder line = new StringBuilder("/RESULT ");
        line.append(handNumber).append(' ').append(type).append(' ').append(totalPot).append(' ').append(entries.size());
        for (Entry e : entries) {
            line.append(' ').append(e.id()).append(',').append(e.nickname()).append(',')
                    .append(e.category()).append(',').append(e.award()).append(',').append(e.refund()).append(',')
                    .append(cardsToWire(e.hand())).append(',').append(cardsToWire(e.bestFive()));
        }
        line.append(' ').append(pots.size());
        for (Pot pot : pots) {
            line.append(' ').append(pot.amount()).append(',')
                    .append(pot.eligible().stream().map(String::valueOf).collect(Collectors.joining(":")))
                    .append(',').append(pot.payouts().entrySet().stream()
                            .map(e -> e.getKey() + "=" + e.getValue()).collect(Collectors.joining(":")));
        }
        return line.toString();
    }
    private static String cardsToWire(List<Card> cards) {
        return cards.isEmpty() ? "-" : cards.stream().map(Card::toWire).collect(Collectors.joining(":"));
    }
    private static List<Card> parseCards(String text) {
        List<Card> cards = new ArrayList<>();
        if (!text.equals("-")) { for (String code : text.split(":")) { cards.add(Card.fromWire(code)); } }
        return cards;
    }
    public static HandResult parse(String line) {
        String[] f = line.split(" ");
        if (f.length < 6 || !f[0].equals("/RESULT")) { throw new IllegalArgumentException("결과 형식 오류"); }
        long number = Long.parseLong(f[1]);
        String type = f[2];
        int total = Integer.parseInt(f[3]), count = Integer.parseInt(f[4]);
        if (number < 0 || total < 0 || count < 0 || count > 6 || f.length < 6 + count
                || !List.of("NONE", "FOLD", "SHOWDOWN").contains(type)) {
            throw new IllegalArgumentException("결과 값 오류");
        }
        List<Entry> entries = new ArrayList<>();
        Map<Integer, Integer> expected = new LinkedHashMap<>();
        long returned = 0, paid = 0;
        for (int i = 0; i < count; i++) {
            String[] p = f[5 + i].split(",");
            if (p.length != 7) { throw new IllegalArgumentException("결과 참가자 형식 오류"); }
            int id = Integer.parseInt(p[0]), category = Integer.parseInt(p[2]);
            int award = Integer.parseInt(p[3]), refund = Integer.parseInt(p[4]);
            List<Card> hand = parseCards(p[5]), best = parseCards(p[6]);
            if (id <= 0 || expected.containsKey(id) || award < 0 || refund < 0 || (type.equals("SHOWDOWN")
                    ? category < 0 || category > 9 || hand.size() != 2 || best.size() != 5
                    : category != -1 || !hand.isEmpty() || !best.isEmpty())) {
                throw new IllegalArgumentException("결과 카드 또는 지급액 오류");
            }
            paid += award; returned += refund; expected.put(id, award);
            entries.add(new Entry(id, p[1], category, award, refund, hand, best));
        }
        int potCount = Integer.parseInt(f[5 + count]);
        if (potCount < 0 || potCount > 6 || f.length != 6 + count + potCount) {
            throw new IllegalArgumentException("팟 개수 오류");
        }
        List<Pot> pots = new ArrayList<>();
        Map<Integer, Integer> actual = new LinkedHashMap<>();
        long potSum = 0;
        for (int i = 0; i < potCount; i++) {
            String[] p = f[6 + count + i].split(",");
            if (p.length != 3) { throw new IllegalArgumentException("팟 형식 오류"); }
            int amount = Integer.parseInt(p[0]);
            List<Integer> eligible = new ArrayList<>();
            for (String id : p[1].split(":")) { eligible.add(Integer.parseInt(id)); }
            Map<Integer, Integer> payouts = new LinkedHashMap<>();
            long sum = 0;
            for (String pair : p[2].split(":")) {
                String[] parts = pair.split("=");
                if (parts.length != 2) { throw new IllegalArgumentException("팟 지급 형식 오류"); }
                int id = Integer.parseInt(parts[0]), chips = Integer.parseInt(parts[1]);
                if (!eligible.contains(id) || chips <= 0 || payouts.put(id, chips) != null) {
                    throw new IllegalArgumentException("팟 승자 오류");
                }
                actual.merge(id, chips, Integer::sum); sum += chips;
            }
            if (amount <= 0 || sum != amount || eligible.stream().distinct().count() != eligible.size()
                    || !expected.keySet().containsAll(eligible)) { throw new IllegalArgumentException("팟 합계 또는 자격 오류"); }
            potSum += amount; pots.add(new Pot(amount, eligible, payouts));
        }
        for (Map.Entry<Integer, Integer> e : expected.entrySet()) {
            if (actual.getOrDefault(e.getKey(), 0).intValue() != e.getValue().intValue()) {
                throw new IllegalArgumentException("참가자별 지급 합계 오류");
            }
        }
        if (paid != potSum || paid + returned != total || (type.equals("NONE") && (number != 0 || count != 0 || total != 0))
                || (type.equals("FOLD") && count != 1) || (type.equals("SHOWDOWN") && count < 2)) {
            throw new IllegalArgumentException("정산 합계 오류");
        }
        return new HandResult(number, type, total, entries, pots);
    }
}
