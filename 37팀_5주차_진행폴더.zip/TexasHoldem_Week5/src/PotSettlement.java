import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** 메인팟·사이드팟 계산. 담당: 표신현
 * 화면이나 소켓을 사용하지 않는 계산 클래스이다. 실제 칩 지급은 GameTable에서 한다.
 */
public final class PotSettlement {
    private PotSettlement() { }
    public record Contribution(int id, int amount, boolean eligible, HandEvaluator.Value value) { }
    public record Settlement(List<HandResult.Pot> pots, Map<Integer, Integer> awards,
            Map<Integer, Integer> refunds) { }
    private record Layer(int amount, List<Integer> eligible) { }

    public static Settlement calculate(List<Contribution> players, int dealerId) {
        List<Layer> layers = new ArrayList<>();
        Map<Integer, Integer> refunds = new LinkedHashMap<>();
        TreeSet<Integer> levels = new TreeSet<>();
        for (Contribution p : players) { if (p.amount() > 0) { levels.add(p.amount()); } }
        int previous = 0;
        for (int level : levels) {
            List<Contribution> contributors = players.stream().filter(p -> p.amount() >= level).toList();
            int amount = (level - previous) * contributors.size();
            previous = level;
            if (contributors.size() == 1) {
                // 다른 사람이 맞추지 않은 초과 금액은 승리 상금이 아니라 본인에게 반환한다.
                refunds.merge(contributors.get(0).id(), amount, Integer::sum);
                continue;
            }
            List<Integer> eligible = contributors.stream().filter(Contribution::eligible)
                    .map(Contribution::id).toList();
            if (eligible.isEmpty()) { throw new IllegalStateException("팟에 승부 가능한 참가자가 없습니다."); }
            // 폴드한 사람의 기여액 경계 때문에 같은 자격의 팟이 나뉘면 합친다.
            // 합친 뒤 홀수 칩을 분배해야 특정 승자가 나머지를 중복해서 받지 않는다.
            if (!layers.isEmpty() && layers.get(layers.size() - 1).eligible().equals(eligible)) {
                Layer last = layers.remove(layers.size() - 1);
                amount += last.amount();
            }
            layers.add(new Layer(amount, eligible));
        }
        Map<Integer, Integer> awards = new LinkedHashMap<>();
        List<HandResult.Pot> pots = new ArrayList<>();
        for (Layer layer : layers) {
            List<Integer> winners = new ArrayList<>();
            HandEvaluator.Value best = null;
            for (Contribution p : players) {
                if (!layer.eligible().contains(p.id())) { continue; }
                // 폴드 승리처럼 자격자가 한 명이면 카드 평가 없이 그 사람이 받는다.
                int comparison = best == null ? 1 : p.value().compareTo(best);
                if (comparison > 0) { best = p.value(); winners.clear(); }
                if (comparison >= 0) { winners.add(p.id()); }
            }
            // 남는 칩은 딜러 다음 자리부터 승자에게 한 개씩 배분한다.
            winners.sort(Comparator.comparingInt((Integer id) -> id > dealerId ? 0 : 1)
                    .thenComparingInt(Integer::intValue));
            int share = layer.amount() / winners.size(), odd = layer.amount() % winners.size();
            Map<Integer, Integer> payouts = new LinkedHashMap<>();
            for (int i = 0; i < winners.size(); i++) {
                int id = winners.get(i), paid = share + (i < odd ? 1 : 0);
                payouts.put(id, paid); awards.merge(id, paid, Integer::sum);
            }
            pots.add(new HandResult.Pot(layer.amount(), layer.eligible(), payouts));
        }
        return new Settlement(List.copyOf(pots), Map.copyOf(awards), Map.copyOf(refunds));
    }
}
