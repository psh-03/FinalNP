@echo off
title Holdem Week5 Server
chcp 949 >nul
cd /d "%~dp0"
java -jar dist\week5-server.jar %*
pause
