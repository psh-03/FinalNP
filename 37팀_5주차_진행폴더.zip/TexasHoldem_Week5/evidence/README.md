# 5주차 확인 기록

검사 환경: Linux OpenJDK 21, Java 17 대상 class 파일. 검사는 이 환경에서 실제 실행했습니다.

- game_rules_result.txt: 기존 차례·베팅과 무작위 200판.
- showdown_rules_result.txt: 족보·키커·정산 159개 검사.
- allin_rules_result.txt: 팟 분리, 초과 반환, 짧은 올인, 블라인드, 무작위 1000판과 퇴장 300개 시나리오.
- network_results.json: 일반 TCP 검사 37개.
- allin_network_results.json: 3인 올인·퇴장 TCP 검사 21개.
- UiSmokeTest_result.txt / AllInUiTest_result.txt: 실제 ClientMain 2개/3개와 서버의 연결 및 Swing 화면 검사.
- protocol 텍스트: 검사 중 서버로부터 받은 실제 메시지.
- server.log 계열: 해당 검사의 실제 서버 접속 기록. 포트는 충돌 방지를 위해 검사마다 임시 배정했습니다.

UI 그림은 별도의 모형이 아니라 실제 GameView 패널의 headless 렌더링입니다.
Windows BAT, Eclipse 프로그램 자체, 한글 입력기, 물리적으로 서로 다른 PC의 연결은 이 환경에서 직접 실행하지 않았습니다.
JAR에는 src만 들어 있습니다. tests의 카드·칩 고정 기능은 테스트용이며 게임 실행에는 없습니다.
