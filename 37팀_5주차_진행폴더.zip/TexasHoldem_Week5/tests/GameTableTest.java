import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** 별도 라이브러리 없이 실행하는 게임 규칙 검사. 게임 src와 분리한다. */
public class GameTableTest {
    private static int checks;
    private static void check(boolean ok, String label) {
        if (!ok) { throw new AssertionError(label); }
        checks++;
    }
    private static GameTable table(int count) {
        GameTable t = new GameTable();
        for (int i = 0; i < count; i++) { t.addPlayer("참가자" + (i + 1)); }
        return t;
    }
    private static void reject(GameTable t, Runnable call, String label) {
        String before = t.snapshot().toWire();
        boolean rejected = false;
        try { call.run(); } catch (IllegalArgumentException | IllegalStateException e) { rejected = true; }
        check(rejected, label + " 거절");
        check(before.equals(t.snapshot().toWire()), label + " 상태 불변");
    }
    private static void checkOrCall(GameTable t) {
        GameState s = t.snapshot();
        t.act(s.turnId, s.currentBet == s.find(s.turnId).bet() ? "CHECK" : "CALL", 0);
    }
    private static void invariant(GameTable t, int chips) {
        GameState s = t.snapshot();
        check(HandResult.parse(t.getResult().toWire()).toWire().equals(t.getResult().toWire()), "정산 결과 직렬화 왕복");
        check(s.seats.stream().mapToInt(GameState.Seat::chips).sum() + s.pot == chips, "칩 총합 보존");
        check(s.seats.stream().allMatch(p -> p.chips() >= 0), "음수 잔액 금지");
        check(GameState.parse(s.toWire()).toWire().equals(s.toWire()), "공개 상태 직렬화 왕복");
        Set<String> visible = new HashSet<>();
        for (GameState.Seat p : s.seats) {
            for (Card c : t.getHand(p.id())) { check(visible.add(c.toWire()), "개인 카드 중복 없음"); }
        }
        for (Card c : s.board) { check(visible.add(c.toWire()), "개인/공용 카드 중복 없음"); }
        if (s.running()) {
            check(s.find(s.turnId) != null && s.find(s.turnId).status().equals("PLAY"), "진행 가능한 차례");
        }
    }

    public static void main(String[] args) {
        GameTable t = table(2);
        final GameTable a = t;
        reject(t, () -> a.startGame(2), "일반 참가자 시작");
        t.startGame(1);
        GameState s = t.snapshot();
        check(s.dealerId == 1 && s.smallBlindId == 1 && s.bigBlindId == 2 && s.turnId == 1, "2인 블라인드와 첫 차례");
        check(s.pot == 30 && s.find(1).chips() == 990 && s.find(2).chips() == 980, "블라인드 칩 반영");
        reject(t, () -> a.startGame(1), "진행 중 재시작");
        reject(t, () -> a.act(2, "FOLD", 0), "다른 사람 차례");
        reject(t, () -> a.act(1, "CHECK", 0), "콜 금액이 있는 체크");
        reject(t, () -> a.act(1, "RAISE", 39), "최소 레이즈 미만");
        reject(t, () -> a.act(1, "RAISE", Integer.MAX_VALUE), "과도한 금액");
        t.act(1, "CALL", 0);
        check(t.snapshot().phase.equals("PREFLOP") && t.snapshot().turnId == 2, "BB 행동 기회 유지");
        t.act(2, "CHECK", 0);
        check(t.snapshot().phase.equals("FLOP") && t.snapshot().board.size() == 3 && t.snapshot().turnId == 2, "플롭 3장과 2인 후반 순서");
        t.act(2, "CHECK", 0);
        t.act(1, "BET", 50);
        check(t.snapshot().turnId == 2 && t.snapshot().phase.equals("FLOP"), "체크했던 상대가 베트에 응답");
        reject(t, () -> a.act(2, "RAISE", 99), "직전 베트 크기보다 작은 레이즈");
        t.act(2, "RAISE", 150);
        check(t.snapshot().minRaise == 100, "레이즈 증가분 저장");
        reject(t, () -> a.act(1, "RAISE", 249), "재레이즈 최소 총액");
        t.act(1, "CALL", 0);
        check(t.snapshot().phase.equals("TURN") && t.snapshot().board.size() == 4 && t.snapshot().currentBet == 0, "턴 전환과 단계 베팅 초기화");
        while (t.isRunning()) { checkOrCall(t); invariant(t, 2000); }
        check(t.snapshot().phase.equals("SHOWDOWN") && t.snapshot().board.size() == 5 && t.snapshot().pot == 0 && t.getResult().totalPot() == 340, "리버 종료 후 정산 완료");
        int settled1 = t.snapshot().find(1).chips(), settled2 = t.snapshot().find(2).chips();
        t.startGame(1);
        s = t.snapshot();
        check(s.dealerId == 2 && s.smallBlindId == 2 && s.bigBlindId == 1, "다음 판 딜러 이동");
        check(s.find(1).chips() == settled1 - 20 && s.find(2).chips() == settled2 - 10 && s.pot == 30, "정산 결과 유지 후 새 블라인드");
        t.act(2, "FOLD", 0);
        check(t.snapshot().phase.equals("FINISHED") && t.snapshot().find(1).chips() == settled1 + 10 && t.snapshot().pot == 0, "폴드 승리 즉시 지급");
        reject(t, () -> a.act(2, "FOLD", 0), "판 종료 뒤 중복 지급 금지");
        t.startGame(1);
        check(t.snapshot().find(1).chips() == settled1 && t.snapshot().find(2).chips() == settled2 - 30, "폴드 승리 결과 다음 판 유지");

        t = table(3); t.startGame(1);
        check(t.snapshot().turnId == 1 && t.snapshot().smallBlindId == 2 && t.snapshot().bigBlindId == 3, "3인 첫 차례");
        List<Card> original = t.getHand(1);
        int newcomer = t.addPlayer("새참가자").id;
        check(t.getHand(newcomer).isEmpty() && t.snapshot().find(newcomer).status().equals("WAIT"), "중도 접속 다음 판 대기");
        check(t.getHand(1).equals(original) && t.snapshot().pot == 30, "중도 접속 기존 판 유지");
        t.removePlayer(2);
        check(t.snapshot().turnId == 1 && t.snapshot().find(2).status().equals("LEFT"), "비차례 퇴장 시 현재 차례 유지");
        t.removePlayer(1);
        check(t.snapshot().hostId == 3 && t.snapshot().find(3).chips() == 1010, "차례 퇴장 폴드와 방장 이전");
        t.startGame(3);
        check(t.getHand(newcomer).size() == 2 && t.snapshot().seats.size() == 2, "다음 판 대기자 참여와 퇴장 자리 정리");
        t.removePlayer(3); t.removePlayer(newcomer);
        check(t.snapshot().phase.equals("WAITING") && t.snapshot().seats.isEmpty(), "모두 퇴장한 뒤 초기화");

        t = table(6); t.startGame(1);
        while (t.isRunning()) { checkOrCall(t); }
        for (int id = 2; id <= 6; id++) { t.removePlayer(id); }
        check(t.snapshot().seats.size() == 1 && t.snapshot().pot == 0, "정산 후 퇴장자 자리 정리");
        int remainingChips = t.snapshot().find(1).chips();
        t.addPlayer("다음참가자"); t.startGame(1);
        invariant(t, remainingChips + 1000);
        check(t.snapshot().seats.size() == 2 && t.isRunning(), "정원 상태에서 다섯 명 퇴장해도 새 참가 후 재시작 가능");

        Random random = new Random(37);
        int rounds = 0;
        for (int n = 2; n <= 6; n++) {
            for (int round = 0; round < 40; round++) {
                t = table(n); t.startGame(1);
                int moves = 0;
                while (t.isRunning()) {
                    s = t.snapshot();
                    GameState.Seat actor = s.find(s.turnId);
                    int due = s.currentBet - actor.bet();
                    int minimum = s.currentBet == 0 ? 20 : s.currentBet + s.minRaise;
                    int choice = random.nextInt(10);
                    if (due >= actor.chips() || choice == 0) { t.act(actor.id(), "FOLD", 0); }
                    else if (choice < 3 && actor.canRaise() && minimum - actor.bet() < actor.chips()) {
                        t.act(actor.id(), s.currentBet == 0 ? "BET" : "RAISE", minimum);
                    } else { checkOrCall(t); }
                    invariant(t, n * 1000);
                    check(++moves < 500, "차례 진행이 끝남");
                }
                rounds++;
            }
        }
        System.out.println("PASS " + checks + " assertions, " + rounds + " randomized hands (2-6 players)");
    }
}
