import java.awt.Font;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/** 실제 ClientMain 3개를 TCP에 접속한다. JFrame 없이 GameView를 그려 자동 검사한다. */
public final class AllInUiTest extends UiSmokeTest {
    static ClientMain c;
    static void move(ClientMain who, String key, Integer amount) throws Exception {
        click(who, key, amount);
        await(() -> state(a).toWire().equals(state(c).toWire()));
    }
    public static void main(String[] args) throws Exception {
        int port = Integer.parseInt(args[0]); String dir = args[1];
        SwingUtilities.invokeAndWait(() -> {
            Font font = new Font("Dialog", Font.PLAIN, 14);
            for (String key : new String[] {"Label.font", "Button.font", "TextField.font", "TextArea.font", "Table.font", "TableHeader.font"}) {
                UIManager.put(key, font);
            }
            a = new ClientMain(); b = new ClientMain(); c = new ClientMain();
        });
        String[] names = {"준석", "신현", "시연참가자"};
        ClientMain[] clients = {a, b, c};
        for (int i = 0; i < clients.length; i++) {
            ClientMain client = clients[i]; String name = names[i];
            SwingUtilities.invokeAndWait(() -> {
                try {
                    ((JTextField)field(view(client), "nicknameField")).setText(name);
                    ((JTextField)field(view(client), "portField")).setText(String.valueOf(port));
                    client.connect("127.0.0.1", port, name);
                } catch (Exception e) { throw new RuntimeException(e); }
            });
            await(() -> state(client) != null && state(a).toWire().equals(state(client).toWire()));
        }
        await(() -> state(a).toWire().equals(state(b).toWire()) && state(a).toWire().equals(state(c).toWire()));
        SwingUtilities.invokeAndWait(() -> { a.sendChat("이번에는 올인과 사이드팟을 확인할게요."); b.sendChat("팟별 지급액과 반환액을 비교해 볼게요."); });
        move(a, "startButton", null);
        move(a, "betButton", 100); move(b, "callButton", null); move(c, "foldButton", null);
        move(b, "betButton", 100); move(a, "foldButton", null);
        await(() -> (Long)field(view(a), "displayedResult") == 1 && (Long)field(view(b), "displayedResult") == 1
                && (Long)field(view(c), "displayedResult") == 1);
        move(a, "startButton", null);
        await(() -> (Long)field(view(a), "displayedResult") == 0);
        move(b, "allInButton", null); move(c, "callButton", null);
        SwingUtilities.invokeAndWait(() -> {
            try {
                check(button(a, "callButton").isEnabled() && button(a, "allInButton").isEnabled(), "Short-stack call and all-in enabled");
                check(!button(a, "checkButton").isEnabled() && !button(a, "betButton").isEnabled(), "Check/raise disabled facing all-ins");
                check(!button(b, "allInButton").isEnabled(), "Already all-in player cannot act");
                save(a, dir + "/game_allin.png");
            } catch (Exception e) { throw new RuntimeException(e); }
        });
        move(a, "callButton", null);
        await(() -> (Long)field(view(a), "displayedResult") == 2 && (Long)field(view(b), "displayedResult") == 2
                && (Long)field(view(c), "displayedResult") == 2);
        SwingUtilities.invokeAndWait(() -> {
            try {
                String result = ((JTextArea)field(view(a), "resultArea")).getText();
                check(result.equals(((JTextArea)field(view(b), "resultArea")).getText())
                        && result.equals(((JTextArea)field(view(c), "resultArea")).getText()), "All three result panels equal");
                check(result.contains("메인팟: 2700개") && result.contains("사이드팟 1: 160개")
                        && result.contains("초과 베팅 반환: 140개"), "Main/side pot and refund displayed");
                check(state(a).seats.stream().mapToInt(GameState.Seat::chips).sum() == 3000 && state(a).pot == 0, "Final chip conservation");
                check(!button(a, "allInButton").isEnabled() && !button(b, "callButton").isEnabled(), "Actions disabled after payout");
                boolean ended = state(a).seats.stream().filter(p -> p.chips() > 0).count() < 2;
                check(button(a, "resetButton").isEnabled() == ended, "New-game button only after elimination");
                check(!button(b, "resetButton").isEnabled(), "Only host resets chips");
                save(a, dir + "/game_sidepots.png");
                for (ClientMain client : clients) { client.disconnect(); }
                for (ClientMain client : clients) { check(!button(client, "allInButton").isEnabled(), "Disconnect clears controls"); }
            } catch (Exception e) { throw new RuntimeException(e); }
        });
        System.out.println("PASS actual 3-client TCP + Swing: ALLIN button, short call, raise restriction, automatic runout, identical pot/refund results, chip total, reset availability, disconnect; headless rendering");
    }
}
