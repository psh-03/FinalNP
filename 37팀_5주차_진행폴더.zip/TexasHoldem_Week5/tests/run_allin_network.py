"""3개 TCP 접속으로 금액이 다른 올인/사이드팟/퇴장을 검사한다. Python 3 표준 라이브러리."""
from pathlib import Path
import json, socket, subprocess, time
from run_checks import Peer, move, rejected, parse_result, oracle, check, RESULTS

ROOT = Path(__file__).resolve().parents[1]

def start(peers):
    host = next(p for p in peers if p.id == peers[0].state()['host'])
    rev = host.state()['rev']; host.send(f'/START {rev}')
    for p in peers: p.sync(rev+1)

def run(port):
    peers=[]
    try:
        for name in ('준석','신현','시연참가자'):
            peers.append(Peer(port,name).join())
            for p in peers: p.sync(peers[-1].state()['rev'])
        a,b,c=peers
        start(peers)
        # 정상 명령만으로 서로 다른 스택을 만든다. 서버에 칩/카드 조작 명령은 없다.
        move(a,'RAISE',100,peers); move(b,'CALL',all_peers=peers); move(c,'FOLD',all_peers=peers)
        move(b,'BET',100,peers); move(a,'FOLD',all_peers=peers)
        check([a.state()['players'][p.id]['chips'] for p in peers]==[900,1120,980], '준비 판 정산으로 서로 다른 스택 생성')
        for p in peers:p.wait(lambda x:x.startswith('/RESULT 1 FOLD '))
        marks={p:len(p.lines) for p in peers}; start(peers)
        hands={p.id:p.wait(lambda x:x.startswith('/HAND '),marks[p]).split()[1:] for p in peers}
        move(b,'ALLIN',all_peers=peers)
        check(a.state()['players'][b.id]['status']=='ALLIN', 'ALLIN 요청과 공개 상태 반영')
        move(c,'CALL',all_peers=peers)
        check(not a.state()['players'][a.id]['can_raise'], '상대가 모두 올인이면 추가 레이즈 금지 상태 전달')
        rejected(a,f'/ACTION {a.state()["rev"]} RAISE 2000','상대 없는 레이즈 거절')
        move(a,'CALL',all_peers=peers)
        state=a.state(); results=[p.wait(lambda x:x.startswith('/RESULT 2 SHOWDOWN ')) for p in peers]
        check(len(set(results))==1 and len({p.state()['raw'] for p in peers})==1, '3개 접속의 상태와 사이드팟 결과 일치')
        result=parse_result(results[0]); board=state['board']
        check(len(board)==5 and state['turn']==0 and state['pot']==0, '올인 후 공용 카드 자동 공개 및 정산')
        check([p['amount'] for p in result['pots']]==[2700,160], '서로 다른 올인 -> 메인팟 2700, 사이드팟 160')
        check(result['entries'][b.id]['refund']==140 and sum(e['refund'] for e in result['entries'].values())==140,'맞춰지지 않은 초과 140 반환')
        scores={id:oracle(hand+board) for id,hand in hands.items()}
        expected={p.id:0 for p in peers}
        for pot in result['pots']:
            best=max(scores[id] for id in pot['eligible'])
            winners=[id for id in pot['eligible'] if scores[id]==best]
            winners.sort(key=lambda id:(id<=state['dealer'],id))
            actual={id:pot['amount']//len(winners)+(i<pot['amount']%len(winners)) for i,id in enumerate(winners)}
            check(pot['payouts']==actual, '독립 족보 비교와 팟별 지급 일치')
            for id,amount in actual.items():expected[id]+=amount
        for p in peers:
            e=result['entries'][p.id]
            check(e['award']==expected[p.id] and state['players'][p.id]['chips']==expected[p.id]+e['refund'], '실제 칩 = 팟 수령+반환 '+str(p.id))
            check(e['hand']==hands[p.id] and oracle(e['best'])==scores[p.id], '공개 카드와 최상위 5장 '+str(p.id))
        check(sum(p['chips'] for p in state['players'].values())==3000, '네트워크 전체 칩 3000 보존')
        (ROOT/'evidence/three_client_allin_protocol.txt').write_text('\n'.join(a.lines),encoding='utf-8')
    finally:
        for p in peers:p.close()

def disconnected_allin(port):
    peers=[]
    try:
        for name in ('연결A','연결B','연결C'):
            peers.append(Peer(port,name).join())
            for p in peers:p.sync(peers[-1].state()['rev'])
        a,b,c=peers;start(peers)
        move(a,'ALLIN',all_peers=peers);rev=b.state()['rev'];a.close();b.sync(rev+1);c.sync(rev+1)
        check(b.state()['turn']==b.id and b.state()['players'][a.id]['status']=='LEFT', '올인 후 연결 종료에도 다음 차례 유지')
        move(b,'CALL',all_peers=[b,c]);move(c,'CALL',all_peers=[b,c])
        r=parse_result(b.wait(lambda x:x.startswith('/RESULT 1 SHOWDOWN ')))
        check(a.id in r['entries'] and r['total']==3000, '연결 종료된 올인 참가자도 쇼다운 자격 유지')
        check(sum(e['award']+e['refund'] for e in r['entries'].values())==3000, '퇴장 사례의 팟 지급 합계 보존')
        check(a.id not in b.state()['players'], '정산 뒤 퇴장 자리 비우기')
    finally:
        for p in peers:p.close()

def execute(test, name):
    with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
    with (ROOT/'evidence'/f'{name}_server.log').open('w',encoding='utf-8') as log:
        server=subprocess.Popen(['java','-jar',str(ROOT/'dist/week5-server.jar'),str(port)],stdout=log,stderr=log)
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.2):break
                except OSError:time.sleep(.05)
            else:raise AssertionError('서버 시작 시간 초과')
            test(port)
        finally:server.terminate();server.wait(timeout=5)

if __name__=='__main__':
    execute(run,'allin');execute(disconnected_allin,'allin_disconnect')
    (ROOT/'evidence/allin_network_results.json').write_text(json.dumps({'environment':'실제 JAR + 3 TCP 접속','tests':RESULTS},ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS',len(RESULTS),'all-in TCP integration checks')
