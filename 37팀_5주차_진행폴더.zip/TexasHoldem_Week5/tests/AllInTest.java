import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** 5주차의 올인·사이드팟 경계 사례. 카드/칩 고정은 테스트에서만 사용한다. */
public final class AllInTest {
    private static int checks, randomHands;
    private static void check(boolean ok, String name) { if (!ok) { throw new AssertionError(name); } checks++; }
    private static GameTable table(int... stacks) {
        GameTable t = new GameTable();
        for (int i = 0; i < stacks.length; i++) { t.addPlayer("참가자" + (i + 1)).chips = stacks[i]; }
        t.startGame(1); return t;
    }
    private static List<Card> cards(String codes) { return Arrays.stream(codes.split(" ")).map(Card::fromWire).toList(); }
    private static HandEvaluator.Value rank(String codes) { return HandEvaluator.evaluate(cards(codes)); }
    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(o);
    }
    @SuppressWarnings("unchecked")
    private static void list(Object o, String name, String codes) throws Exception {
        List<Card> list = (List<Card>)field(o, name); list.clear(); list.addAll(cards(codes));
    }
    private static GameTable.Player player(GameTable t, int id) throws Exception {
        return (GameTable.Player)((Map<?, ?>)field(t, "players")).get(id);
    }
    private static void reject(GameTable t, Runnable action, String name) {
        String before = t.snapshot().toWire(); boolean rejected = false;
        try { action.run(); } catch (IllegalArgumentException | IllegalStateException e) { rejected = true; }
        check(rejected && before.equals(t.snapshot().toWire()), name + " 거절 및 상태 불변");
    }
    private static void call(GameTable t) {
        GameState s = t.snapshot();
        t.act(s.turnId, s.currentBet == s.find(s.turnId).bet() ? "CHECK" : "CALL", 0);
    }
    private static void finish(GameTable t) { int n = 0; while (t.isRunning()) { call(t); check(++n < 100, "자동 진행 유한"); } }
    private static void invariant(GameTable t, int total) {
        GameState s = t.snapshot(); HandResult r = t.getResult();
        check(s.seats.stream().mapToInt(GameState.Seat::chips).sum() + s.pot == total, "칩 총합 보존");
        check(s.seats.stream().allMatch(p -> p.chips() >= 0), "음수 칩 없음");
        check(GameState.parse(s.toWire()).toWire().equals(s.toWire()), "STATE 직렬화 왕복");
        check(HandResult.parse(r.toWire()).toWire().equals(r.toWire()), "RESULT 직렬화 왕복");
        if (t.isRunning()) {
            check(s.turnId > 0 && s.find(s.turnId).chips() > 0 && s.find(s.turnId).status().equals("PLAY"), "행동 가능한 차례만 배정");
            check(s.seats.stream().mapToInt(GameState.Seat::contribution).sum() == s.pot, "누적 기여액과 팟 일치");
        } else {
            check(s.pot == 0 && s.turnId == 0, "정산 후 진행 상태 초기화");
            check(r.entries().stream().mapToInt(e -> e.award() + e.refund()).sum() == r.totalPot(), "수령+반환 합계");
        }
    }
    private static PotSettlement.Contribution c(int id, int amount, boolean eligible, HandEvaluator.Value value) {
        return new PotSettlement.Contribution(id, amount, eligible, value);
    }
    private static void potTests() {
        var high = rank("S14 H14 D12 C9 S6");
        var mid = rank("S13 H13 D12 C9 S6");
        var low = rank("S12 H12 D11 C9 S6");
        var r = PotSettlement.calculate(List.of(c(1, 100, true, high), c(2, 300, true, mid), c(3, 500, true, low)), 1);
        check(r.pots().size() == 2 && r.pots().get(0).amount() == 300 && r.pots().get(1).amount() == 400, "100/300/500 -> 팟 300/400");
        check(r.awards().equals(Map.of(1, 300, 2, 400)) && r.refunds().equals(Map.of(3, 200)), "서로 다른 팟 승자와 초과 200 반환");
        r = PotSettlement.calculate(List.of(c(1, 100, true, high), c(2, 300, true, mid), c(3, 300, false, low)), 1);
        check(r.awards().equals(Map.of(1, 300, 2, 400)), "폴드 기여액 포함, 폴드 승부 자격 제외");
        r = PotSettlement.calculate(List.of(c(1, 1, false, null), c(2, 3, true, high), c(3, 3, true, high), c(4, 2, false, null)), 1);
        check(r.pots().size() == 1 && r.pots().get(0).amount() == 9, "같은 자격의 층은 하나로 합침");
        check(r.awards().equals(Map.of(2, 5, 3, 4)), "합친 팟의 홀수 칩을 딜러 다음 승자에게");
        r = PotSettlement.calculate(List.of(c(1, 5, true, high), c(2, 7, true, high), c(3, 7, true, high)), 1);
        check(r.pots().size() == 2 && r.awards().equals(Map.of(1, 5, 2, 7, 3, 7)), "팟별 무승부 분배");
    }
    private static void fixedAllIn() throws Exception {
        GameTable t = table(500, 300, 100);
        list(player(t, 1), "hand", "S12 H12"); list(player(t, 2), "hand", "S13 H13"); list(player(t, 3), "hand", "S14 H14");
        Object deck = field(t, "deck");
        list(deck, "cards", "S3 C2 D4 H6 D3 C8 S5 D10");
        Field index = Deck.class.getDeclaredField("nextIndex"); index.setAccessible(true); index.setInt(deck, 0);
        t.act(1, "ALLIN", 0);
        check(t.snapshot().find(1).status().equals("ALLIN") && t.snapshot().turnId == 2, "올인 상태 표시와 다음 사람 차례");
        t.act(2, "CALL", 0); t.act(3, "CALL", 0);
        check(!t.isRunning() && t.snapshot().board.size() == 5 && t.snapshot().phase.equals("SHOWDOWN"), "프리플롭 올인 뒤 공용 5장 자동 공개");
        invariant(t, 900);
        check(t.snapshot().find(1).chips() == 200 && t.snapshot().find(2).chips() == 400 && t.snapshot().find(3).chips() == 300, "AA 메인팟 / KK 사이드팟 / QQ 반환");
        check(t.getResult().entries().get(0).refund() == 200 && t.getResult().entries().get(0).award() == 0, "반환과 상금 구분");
        check(t.getResult().pots().get(1).eligible().equals(List.of(1, 2)), "작은 올인 참가자는 사이드팟 자격 없음");
        String result = t.getResult().toWire();
        for (int i = 0; i < 10; i++) { HandResult.parse(t.getResult().toWire()); t.snapshot(); }
        invariant(t, 900); check(t.getResult().toWire().equals(result), "결과 재조회로 중복 지급 없음");
        t.startGame(1); check(t.getResult().type().equals("NONE"), "다음 판 결과 초기화"); invariant(t, 900);
    }
    private static void shortRaiseTests() {
        GameTable t = table(1000, 25, 1000); final GameTable first = t;
        t.act(1, "CALL", 0); t.act(2, "ALLIN", 0);
        check(t.snapshot().currentBet == 25 && t.snapshot().minRaise == 20, "짧은 올인은 최소 레이즈 폭 유지");
        check(t.snapshot().find(3).canRaise(), "아직 행동하지 않은 사람은 레이즈 가능");
        t.act(3, "CALL", 0);
        check(!t.snapshot().find(1).canRaise(), "이미 행동한 사람은 짧은 올인 뒤 재레이즈 금지");
        reject(t, () -> first.act(1, "RAISE", 45), "짧은 올인 뒤 레이즈");
        reject(t, () -> first.act(1, "ALLIN", 0), "금지된 레이즈를 올인으로 우회");
        t.act(1, "CALL", 0); finish(t); invariant(t, 2025);

        t = table(30, 40, 1000, 1000);
        t.act(4, "CALL", 0); t.act(1, "ALLIN", 0); t.act(2, "ALLIN", 0); t.act(3, "CALL", 0);
        check(t.snapshot().find(4).canRaise() && t.snapshot().minRaise == 20, "누적 짧은 올인 10+10이면 재레이즈 열림");
        t.act(4, "RAISE", 60); finish(t); invariant(t, 2070);

        t = table(1000, 1000, 25); final GameTable checked = t;
        call(t); call(t); call(t); // 플롭: 2번이 먼저 행동
        t.act(2, "CHECK", 0); t.act(3, "ALLIN", 0); t.act(1, "CALL", 0);
        check(t.snapshot().currentBet == 5 && !t.snapshot().find(2).canRaise(), "체크 후 최소 베트 미만 올인은 재레이즈 열지 않음");
        reject(t, () -> checked.act(2, "RAISE", 25), "체크 후 짧은 올인 재레이즈");
        finish(t); invariant(t, 2025);

        t = table(1000, 1000, 25);
        call(t); call(t); call(t); t.act(2, "CHECK", 0); t.act(3, "ALLIN", 0);
        t.act(1, "RAISE", 25); // 5에 최소 레이즈 폭 20을 더한다.
        check(t.snapshot().find(2).canRaise() && t.snapshot().minRaise == 20, "정상 레이즈로 이전 체크 참가자 행동 재개");
        finish(t); invariant(t, 2025);
    }
    private static void edgeTests() throws Exception {
        for (int[] stacks : new int[][] {{1, 1}, {10, 15}, {1, 100}, {100, 1}, {5, 7, 10}, {0, 5, 12}}) {
            GameTable t = table(stacks); finish(t); invariant(t, Arrays.stream(stacks).sum());
            check(t.snapshot().board.size() == 5, "부족한 블라인드에서도 쇼다운 완료");
        }
        GameTable t = table(1000, 100, 1000); t.act(1, "CALL", 0); t.act(2, "ALLIN", 0);
        t.removePlayer(2);
        check(!player(t, 2).folded, "올인한 참가자는 연결 종료에도 자격 유지");
        call(t); call(t); finish(t);
        check(t.getResult().entries().stream().anyMatch(e -> e.id() == 2), "퇴장한 올인 참가자도 결과에 포함");
        check(t.snapshot().find(2) == null, "정산 후 퇴장 자리 정리");
        t = table(1000, 1000, 1000); t.act(1, "CALL", 0); t.act(2, "CALL", 0); t.act(3, "CHECK", 0);
        t.removePlayer(1); t.removePlayer(2); // 차례 자동 체크로 남은 사이드팟 자격 유지
        finish(t); check(t.snapshot().pot == 0, "둘의 연속 퇴장에도 정산 완료");
        t = table(1000, 1000); final GameTable reset = t;
        reject(t, () -> reset.resetGame(1), "진행 중 초기화");
        finish(t); player(t, 1).chips = 2000; player(t, 2).chips = 0;
        reject(t, () -> reset.resetGame(2), "방장 외 초기화");
        t.resetGame(1); check(t.snapshot().phase.equals("WAITING") && t.snapshot().find(2).chips() == 1000, "게임 종료 뒤 새 게임 초기화");
        t.startGame(1); invariant(t, 2000);
    }
    private static void randomTests() {
        Random random = new Random(375);
        for (int n = 2; n <= 6; n++) {
            for (int round = 0; round < 200; round++) {
                int[] stacks = new int[n]; for (int i = 0; i < n; i++) { stacks[i] = 1 + random.nextInt(1000); }
                GameTable t = table(stacks); int total = Arrays.stream(stacks).sum(), moves = 0;
                invariant(t, total);
                while (t.isRunning()) {
                    GameState s = t.snapshot(); GameState.Seat p = s.find(s.turnId);
                    int minimum = s.currentBet + s.minRaise, choice = random.nextInt(10);
                    if (choice == 0) { t.act(p.id(), "FOLD", 0); }
                    else if (choice < 3 && (p.canRaise() || p.bet() + p.chips() <= s.currentBet)) { t.act(p.id(), "ALLIN", 0); }
                    else if (choice == 3 && p.canRaise() && p.bet() + p.chips() >= minimum) {
                        t.act(p.id(), s.currentBet == 0 ? "BET" : "RAISE", minimum);
                    } else { call(t); }
                    invariant(t, total); check(++moves < 500, "차례 무한 반복 없음");
                }
                randomHands++;
            }
        }
    }
    private static void disconnectTests() {
        Random random = new Random(735);
        for (int round = 0; round < 300; round++) {
            GameTable t = new GameTable(); List<GameTable.Player> original = new ArrayList<>();
            int count = 2 + random.nextInt(5);
            for (int i = 0; i < count; i++) {
                GameTable.Player p = t.addPlayer("접속" + i); p.chips = 1 + random.nextInt(300); original.add(p);
            }
            int total = original.stream().mapToInt(p -> p.chips).sum(); t.startGame(1); int steps = 0;
            while (t.isRunning()) {
                List<GameTable.Player> connected = original.stream().filter(p -> p.connected).toList();
                if (connected.size() > 1 && random.nextInt(4) == 0) {
                    t.removePlayer(connected.get(random.nextInt(connected.size())).id);
                } else {
                    GameState state = t.snapshot(); GameState.Seat actor = state.find(state.turnId);
                    if (random.nextInt(3) == 0 && (actor.canRaise() || actor.bet() + actor.chips() <= state.currentBet)) {
                        t.act(actor.id(), "ALLIN", 0);
                    } else { call(t); }
                }
                check(original.stream().mapToInt(p -> p.chips).sum() + t.snapshot().pot == total, "퇴장자 보유액 포함 총합 보존");
                HandResult.parse(t.getResult().toWire());
                check(++steps < 150, "무작위 퇴장 뒤 유한 시간 내 정산");
            }
        }
    }
    public static void main(String[] args) throws Exception {
        potTests(); fixedAllIn(); shortRaiseTests(); edgeTests(); randomTests(); disconnectTests();
        System.out.println("PASS " + checks + " all-in / side-pot assertions, " + randomHands + " randomized unequal-stack hands + 300 disconnect scenarios (2-6 players)");
    }
}
