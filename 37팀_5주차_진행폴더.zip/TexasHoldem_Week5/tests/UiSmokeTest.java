import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import java.util.HashSet;
import javax.imageio.ImageIO;
import javax.swing.*;

/** 실제 ClientMain 두 개를 TCP 서버에 연결한 뒤 Swing 화면과 버튼을 검사한다. */
public class UiSmokeTest {
    static ClientMain a, b;
    static Object field(Object object, String name) throws Exception {
        Field f = object.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(object);
    }
    static GameView view(ClientMain client) throws Exception { return (GameView)field(client,"view"); }
    static GameState state(ClientMain client) throws Exception { return (GameState)field(client,"state"); }
    static JButton button(ClientMain c, String key) throws Exception { return (JButton)field(view(c),key); }
    static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); }
    static void await(java.util.concurrent.Callable<Boolean> predicate) throws Exception {
        long end=System.currentTimeMillis()+6000;
        while(System.currentTimeMillis()<end) {
            boolean[] ok={false};
            SwingUtilities.invokeAndWait(()->{try{ok[0]=predicate.call();}catch(Exception e){throw new RuntimeException(e);}});
            if(ok[0])return; Thread.sleep(25);
        }
        throw new AssertionError("UI state timeout");
    }
    static void click(ClientMain c, String key, Integer amount) throws Exception {
        long[] rev={0};
        SwingUtilities.invokeAndWait(()->{
            try{
                rev[0]=state(c).revision;
                if(amount!=null)((JTextField)field(view(c),"amountField")).setText(amount.toString());
                check(button(c,key).isEnabled(),key+" should be enabled");
                button(c,key).doClick();
            }catch(Exception e){throw new RuntimeException(e);}
        });
        await(()->state(a).revision>rev[0] && state(a).toWire().equals(state(b).toWire()));
    }
    static void layout(Container c) {
        c.doLayout(); for(Component child:c.getComponents())if(child instanceof Container)layout((Container)child);
    }
    static void save(ClientMain c,String path) throws Exception {
        GameView v=view(c); v.setSize(1180,870); layout(v);
        for(String name:new String[]{"startButton","checkButton","callButton","foldButton","betButton","betHelpLabel","allInButton","resetButton"}) {
            Component component=(Component)field(v,name);
            Point point=SwingUtilities.convertPoint(component,0,0,v);
            check(point.y+component.getHeight()<=v.getHeight()-10, "Control clipped: "+name+" "+point+" "+component.getSize());
        }
        BufferedImage im=new BufferedImage(1180,870,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=im.createGraphics(); v.printAll(g);g.dispose(); ImageIO.write(im,"png",new File(path));
    }
    public static void main(String[] args)throws Exception{
        int port=Integer.parseInt(args[0]);String dir=args[1];
        SwingUtilities.invokeAndWait(()->{
            Font f=new Font("Dialog",Font.PLAIN,14);
            for(String key:new String[]{"Label.font","Button.font","TextField.font","TextArea.font","Table.font","TableHeader.font"})UIManager.put(key,f);
            a=new ClientMain();b=new ClientMain();
            try{
                ((JTextField)field(view(a),"nicknameField")).setText("준석");
                ((JTextField)field(view(a),"portField")).setText(String.valueOf(port));
                ((JTextField)field(view(b),"portField")).setText(String.valueOf(port));
                ((JTextField)field(view(b),"nicknameField")).setText("신현");
                a.connect("127.0.0.1",port,"준석");
            }catch(Exception e){throw new RuntimeException(e);}
        });
        await(()->state(a)!=null);
        SwingUtilities.invokeAndWait(()->b.connect("127.0.0.1",port,"신현"));
        await(()->state(b)!=null && state(a).seats.size()==2 && state(a).toWire().equals(state(b).toWire()));
        SwingUtilities.invokeAndWait(()->{a.sendChat("콜과 레이즈로 게임을 진행해 볼게요.");b.sendChat("공용 카드와 판돈이 같이 바뀌는지 확인할게요.");});
        click(a,"startButton",null);
        await(()->!((JLabel[])field(view(a),"handLabels"))[0].getText().equals("?")
                && !((JLabel[])field(view(b),"handLabels"))[0].getText().equals("?"));
        SwingUtilities.invokeAndWait(()->{
            try{
                check(!button(a,"startButton").isEnabled(),"Restart disabled while running");
                check(!button(b,"foldButton").isEnabled(),"Other player controls disabled");
                check(!button(a,"checkButton").isEnabled(),"Check disabled facing blind");
                HashSet<String> cards=new HashSet<>();
                for(ClientMain c:new ClientMain[]{a,b})for(JLabel label:(JLabel[])field(view(c),"handLabels"))cards.add(label.getText());
                check(cards.size()==4,"Separate private hands");
            }catch(Exception e){throw new RuntimeException(e);}
        });
        click(a,"callButton",null);click(b,"checkButton",null);
        click(b,"betButton",20);
        SwingUtilities.invokeAndWait(()->{try{
            check(state(a).board.size()==3 && state(a).pot==60,"Flop public state");
            save(a,dir+"/game_flop.png");save(b,dir+"/game_flop_second.png");
        }catch(Exception e){throw new RuntimeException(e);}});
        click(a,"betButton",60);click(b,"callButton",null);
        click(b,"checkButton",null);click(a,"checkButton",null);
        SwingUtilities.invokeAndWait(()->{try{
            check(state(a).phase.equals("RIVER") && state(a).board.size()==5 && state(a).pot==160,"River public state");
            save(b,dir+"/game_river.png");
        }catch(Exception e){throw new RuntimeException(e);}});
        click(b,"checkButton",null);click(a,"checkButton",null);
        SwingUtilities.invokeAndWait(()->{try{
            check(state(a).phase.equals("SHOWDOWN"),"Showdown settled");
            check(button(a,"startButton").isEnabled() && !button(b,"startButton").isEnabled(),"Only host starts next hand");
            check(!button(a,"foldButton").isEnabled() && !button(b,"checkButton").isEnabled(),"No actions after river");
        }catch(Exception e){throw new RuntimeException(e);}});
        await(()->((Long)field(view(a),"displayedResult"))==1 && ((Long)field(view(b),"displayedResult"))==1);
        int[] settled={0};
        SwingUtilities.invokeAndWait(()->{try{
            settled[0]=state(a).find(1).chips();
            String ar=((JTextArea)field(view(a),"resultArea")).getText();
            String br=((JTextArea)field(view(b),"resultArea")).getText();
            check(ar.equals(br) && ar.contains("전체 판돈: 160개") && ar.contains("최상위 5장:"),"Both result panels equal");
            check(((JTabbedPane)field(view(a),"infoTabs")).getSelectedIndex()==1,"Result tab opens");
            check(state(a).pot==0 && state(a).seats.stream().mapToInt(GameState.Seat::chips).sum()==2000,"Payout chip conservation");
            save(a,dir+"/game_showdown.png");
        }catch(Exception e){throw new RuntimeException(e);}});
        click(a,"startButton",null);
        await(()->((Long)field(view(a),"displayedResult"))==0);
        click(b,"foldButton",null);
        await(()->((Long)field(view(a),"displayedResult"))==2);
        SwingUtilities.invokeAndWait(()->{try{
            check(state(a).phase.equals("FINISHED") && state(a).find(1).chips()==settled[0]+10,"Fold winner without refund");
            save(a,dir+"/game_fold.png");
            a.disconnect();b.disconnect();
            check(!button(a,"startButton").isEnabled(),"Disconnected controls disabled");
        }catch(Exception e){throw new RuntimeException(e);}});
        System.out.println("PASS actual ClientMain/GameView via TCP: button enablement, chat, call/bet/raise/check/fold, 3/4/5 board, equal public state, private hands, showdown result tab, equal payouts, fold privacy, next hand result reset; headless Swing rendering");
    }
}
