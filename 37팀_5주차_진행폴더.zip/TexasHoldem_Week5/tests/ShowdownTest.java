import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** 미리 정한 카드로 기대 승자/지급액을 검사한다. 테스트에서만 reflection을 쓴다. */
public final class ShowdownTest {
    private static int checks;
    private static void check(boolean ok, String name) {
        if (!ok) { throw new AssertionError(name); }
        checks++;
    }
    private static List<Card> cards(String text) {
        return Arrays.stream(text.split(" ")).map(Card::fromWire).toList();
    }
    private static HandEvaluator.Value value(String text) { return HandEvaluator.evaluate(cards(text)); }
    private static void higher(String a, String b, String name) { check(value(a).compareTo(value(b)) > 0, name); }
    private static void rankTests() {
        String[] examples = {
            "S14 H11 D9 C6 S3", "S12 H12 D14 C9 S6", "S12 H12 D9 C9 S14",
            "S12 H12 D12 C14 S9", "S9 H8 D7 C6 S5", "S14 S11 S9 S6 S3",
            "S12 H12 D12 C9 S9", "S12 H12 D12 C12 S14", "S9 S8 S7 S6 S5", "S14 S13 S12 S11 S10"
        };
        for (int i = 0; i < examples.length; i++) {
            check(value(examples[i]).category() == i, "족보 종류 " + i);
            if (i > 0) { higher(examples[i], examples[i - 1], "족보 간 순위 " + i); }
        }
        check(value("S14 H2 D3 C4 S5").kickers().equals(List.of(5)), "A2345는 5 하이");
        higher("S6 H2 D3 C4 S5", "S14 H2 D3 C4 S5", "6 하이가 휠보다 높음");
        check(value("S12 H13 D14 C2 S3").category() == 0, "QKA23 연결 금지");
        higher("S12 H12 D14 C9 S6", "D12 C12 S13 H9 D6", "원페어 첫 키커");
        higher("S12 H12 D14 C9 S6", "D12 C12 S14 H8 D7", "원페어 두 번째 키커");
        higher("S12 H12 D14 C9 S7", "D12 C12 S14 H9 D6", "원페어 세 번째 키커");
        higher("S12 H12 D9 C9 S14", "D12 C12 S8 H8 D14", "투페어 낮은 페어");
        higher("S12 H12 D9 C9 S14", "D12 C12 S9 H9 D13", "투페어 키커");
        higher("S12 H12 D12 C14 S9", "S12 H12 D12 C14 S8", "트리플 두 번째 키커");
        higher("S14 S11 S9 S6 S4", "H14 H11 H9 H6 H3", "플러시 다섯 번째 카드");
        higher("S12 H12 D12 C10 S10", "S12 H12 D12 C9 S9", "풀하우스 페어 비교");
        higher("S12 H12 D12 C12 S14", "S12 H12 D12 C12 S13", "포카드 키커");
        check(value("S14 S11 S9 S6 S3").compareTo(value("H14 H11 H9 H6 H3")) == 0, "무늬 우열 없음");
        check(value("S14 H14 D14 S13 H13 D13 C2").kickers().equals(List.of(14, 13)), "트리플 두 개 중 큰 풀하우스");
        check(value("S14 H14 S13 H13 S12 H12 C11").kickers().equals(List.of(14, 13, 12)), "페어 세 개 중 투페어와 키커");
        check(value("S14 S13 S12 S11 S10 H2 D3").category() == 9, "공용 5장만으로 로열 가능");
        List<Card> seven = new ArrayList<>(cards("S14 H14 D14 S13 H13 D13 C2"));
        HandEvaluator.Value original = HandEvaluator.evaluate(seven);
        Random random = new Random(4);
        for (int i = 0; i < 100; i++) {
            Collections.shuffle(seven, random);
            check(HandEvaluator.evaluate(seven).compareTo(original) == 0, "입력 카드 순서 무관");
        }
        boolean rejected = false;
        try { value("S14 S14 H13 D12 C11"); } catch (IllegalArgumentException e) { rejected = true; }
        check(rejected, "중복 카드 거절");
    }

    private static GameTable table(int n) {
        GameTable table = new GameTable();
        for (int i = 1; i <= n; i++) { table.addPlayer("참가자" + i); }
        table.startGame(1);
        return table;
    }
    private static void checkOrCall(GameTable table) {
        GameState state = table.snapshot();
        table.act(state.turnId, state.currentBet == state.find(state.turnId).bet() ? "CHECK" : "CALL", 0);
    }
    private static void toRiver(GameTable table) {
        while (!table.snapshot().phase.equals("RIVER")) { checkOrCall(table); }
    }
    @SuppressWarnings("unchecked")
    private static void setCards(Object target, String field, String codes) throws Exception {
        Field f = target.getClass().getDeclaredField(field); f.setAccessible(true);
        List<Card> list = (List<Card>)f.get(target); list.clear(); list.addAll(cards(codes));
    }
    private static Object player(GameTable table, int id) throws Exception {
        Field f = GameTable.class.getDeclaredField("players"); f.setAccessible(true);
        return ((java.util.Map<?,?>)f.get(table)).get(id);
    }
    private static void finish(GameTable table) { while (table.isRunning()) { checkOrCall(table); } }
    private static void resultChecks(GameTable table, int total) {
        HandResult result = table.getResult();
        check(result.entries().stream().mapToInt(e -> e.award() + e.refund()).sum() == total, "지급 합계");
        check(result.totalPot() == total && table.snapshot().pot == 0, "정산 판돈 기록과 현재 판돈 0");
        check(HandResult.parse(result.toWire()).toWire().equals(result.toWire()), "결과 메시지 왕복");
    }
    private static void settlementTests() throws Exception {
        GameTable table = table(2); toRiver(table);
        setCards(table, "board", "S12 H9 D6 C4 S2");
        setCards(player(table, 1), "hand", "D14 C12");
        setCards(player(table, 2), "hand", "D13 H12");
        finish(table); resultChecks(table, 40);
        check(table.snapshot().find(1).chips() == 1020 && table.snapshot().find(2).chips() == 980, "Q 페어 A 키커 승리");
        String result = table.getResult().toWire();
        for (int i = 0; i < 5; i++) { table.snapshot(); table.getResult(); }
        check(table.snapshot().find(1).chips() == 1020, "결과 조회로 중복 지급 없음");
        table.addPlayer("관전자");
        check(table.getResult().toWire().equals(result), "새 접속에도 완료 결과 유지");
        table.startGame(1);
        check(table.snapshot().find(1).chips() == 1000 && table.snapshot().find(2).chips() == 980, "다음 판에 환불 없음");
        check(table.getResult().type().equals("NONE"), "다음 판 결과 초기화");

        table = table(3); toRiver(table);
        setCards(table, "board", "C10 C11 C12 C13 C14");
        setCards(player(table, 1), "hand", "S2 H3");
        setCards(player(table, 2), "hand", "S4 H5");
        setCards(player(table, 3), "hand", "S6 H7");
        finish(table); resultChecks(table, 60);
        check(table.getResult().entries().stream().allMatch(e -> e.award() == 20 && e.category() == 9), "공용 로열 3인 무승부");

        table = table(3);
        while (table.snapshot().phase.equals("PREFLOP")) { checkOrCall(table); }
        table.act(2, "BET", 21); table.act(3, "CALL", 0); table.act(1, "CALL", 0);
        table.act(2, "CHECK", 0); table.act(3, "FOLD", 0); table.act(1, "CHECK", 0);
        setCards(table, "board", "C10 C11 C12 C13 C14");
        setCards(player(table, 1), "hand", "S2 H3"); setCards(player(table, 2), "hand", "S4 H5");
        finish(table); resultChecks(table, 123);
        check(table.snapshot().find(1).chips() == 1020 && table.snapshot().find(2).chips() == 1021
                && table.snapshot().find(3).chips() == 959, "홀수 칩은 딜러 다음 승자부터 분배");
        check(table.getResult().entries().stream().noneMatch(e -> e.id() == 3), "폴드한 사람 결과 공개와 승자에서 제외");
        table.removePlayer(2);
        check(table.snapshot().pot == 0 && table.snapshot().find(1).chips() == 1020, "정산 뒤 퇴장에도 환불 없음");

        table = table(2); table.act(1, "FOLD", 0); resultChecks(table, 30);
        check(table.getResult().entries().get(0).hand().isEmpty()
                && table.getResult().entries().get(0).bestFive().isEmpty(), "폴드 승리 카드 비공개");
        check(table.snapshot().find(2).chips() == 1010, "폴드 승리 기존 기능 유지");
    }

    // 선택 검사: 52장 중 가능한 5장 2,598,960개를 전부 판정해 알려진 조합 수와 비교한다.
    private static void exhaustive() {
        List<Card> deck = new ArrayList<>();
        for (char suit : "SHDC".toCharArray()) { for (int rank = 2; rank <= 14; rank++) { deck.add(new Card(suit, rank)); } }
        long[] counts = new long[10];
        for (int a = 0; a < 48; a++) for (int b = a + 1; b < 49; b++)
            for (int c = b + 1; c < 50; c++) for (int d = c + 1; d < 51; d++)
                for (int e = d + 1; e < 52; e++) {
                    counts[HandEvaluator.evaluate(List.of(deck.get(a), deck.get(b), deck.get(c), deck.get(d), deck.get(e))).category()]++;
                }
        long[] expected = {1302540, 1098240, 123552, 54912, 10200, 5108, 3744, 624, 36, 4};
        check(Arrays.equals(counts, expected), "모든 5장 족보별 조합 수 " + Arrays.toString(counts));
        System.out.println("PASS all 2,598,960 five-card combinations; categories " + Arrays.toString(counts));
    }
    public static void main(String[] args) throws Exception {
        rankTests(); settlementTests();
        if (args.length > 0 && args[0].equals("--exhaustive")) { exhaustive(); }
        System.out.println("PASS " + checks + " ranking / settlement checks");
    }
}
