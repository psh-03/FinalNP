"""실제 클라이언트 클래스와 서버 JAR을 연결한 Swing 검사. 테스트 .class가 먼저 필요하다."""
from pathlib import Path
import socket, subprocess, time, os
ROOT=Path(__file__).resolve().parents[1]
for name in ('UiSmokeTest','AllInUiTest'):
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
    with (ROOT/'evidence'/f'{name}_server.log').open('w') as log:
        server=subprocess.Popen(['java','-jar',str(ROOT/'dist/week5-server.jar'),str(port)],stdout=log,stderr=log)
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.2):break
                except OSError:time.sleep(.05)
            result=subprocess.run(['java','-Djava.awt.headless=true','-cp',str(ROOT/'dist/week5-client.jar')+os.pathsep+str(ROOT/'test-bin'),name,str(port),str(ROOT/'docs')],text=True,capture_output=True,timeout=40)
            (ROOT/'evidence'/f'{name}_result.txt').write_text(result.stdout+result.stderr,encoding='utf-8')
            print(result.stdout+result.stderr)
            if result.returncode:raise SystemExit(result.returncode)
        finally:
            server.terminate();server.wait(timeout=5)
