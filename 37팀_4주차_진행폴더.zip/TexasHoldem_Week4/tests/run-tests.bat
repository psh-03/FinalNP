@echo off
cd /d "%~dp0.."
if not exist test-bin mkdir test-bin
javac --release 17 -encoding UTF-8 -cp dist\week4-server.jar -d test-bin tests\*.java
if errorlevel 1 goto failed
java -ea -cp "dist\week4-server.jar;test-bin" GameTableTest
if errorlevel 1 goto failed
java -ea -cp "dist\week4-server.jar;test-bin" ShowdownTest
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Test failed. See the error above.
pause
exit /b 1
