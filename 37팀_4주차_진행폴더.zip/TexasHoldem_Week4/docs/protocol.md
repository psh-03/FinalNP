# 4주차 응용 계층 프로토콜

TCP, 기본 포트 5555, UTF-8, 줄바꿈 하나로 메시지 하나를 구분합니다.
닉네임은 공백 없는 문자·숫자·밑줄 1~12자이고 채팅은 1~200자입니다.

| 기능 | 프로토콜 | 형식 | 예시 | 값의 의미 | 전송 방향 | 전송 시점 | 수신 후 처리 |
|---|---|---|---|---|---|---|---|
| 등록 | /JOIN | /JOIN 닉네임 | /JOIN 준석 | 참가자 이름 | 클라이언트 → 서버 | 연결 후 10초 이내 | 중복·인원 검사 후 등록 |
| 승인 | /JOIN_OK | /JOIN_OK ID | /JOIN_OK 1 | 배정 ID | 서버 → 요청자 | 등록 후 | 본인 ID 저장 |
| 채팅 | /CHAT | 요청은 본문, 전달은 닉네임 본문 | /CHAT 준석 안녕 | 서버가 송신자 이름을 붙임 | 클라이언트 → 서버 → 모두 | 채팅 입력 시 | 대화 표시 |
| 시작 | /START | /START 상태번호 | /START 7 | 현재 revision | 클라이언트 → 서버 | 방장 버튼 입력 | 방장·인원 검사 후 시작 |
| 기본 행동 | /ACTION | /ACTION 상태번호 행동 | /ACTION 8 CALL | CHECK, CALL, FOLD | 클라이언트 → 서버 | 행동 버튼 입력 | 차례·상태 검사 후 처리 |
| 금액 행동 | /ACTION | /ACTION 상태번호 행동 총액 | /ACTION 8 RAISE 60 | BET 또는 RAISE, 이번 단계 총액 | 클라이언트 → 서버 | 베팅 입력 | 최소 금액·잔액 검사 |
| 공개 상태 | /STATE | 아래 필드 순서 참조 | 아래 예시 참조 | 단계·차례·칩·판돈·공용 카드 | 서버 → 모두 | 상태 변경 후 | 화면 상태 갱신 |
| 개인 카드 | /HAND | /HAND 카드1 카드2 또는 /HAND | /HAND S14 H13 | 자기 카드 2장 | 서버 → 해당 참가자 | 상태 전송 시 | 자기 카드 갱신 |
| 판 결과 | /RESULT | /RESULT 판번호 종류 판돈 인원 참가자들 | /RESULT 1 FOLD 30 1 2,신현,-1,30,-,- | 아래 결과 필드 참조 | 서버 → 모두 | 상태 전송 시 | 결과 표시만 수행 |
| 결과 초기화 | /RESULT | /RESULT 0 NONE 0 0 | /RESULT 0 NONE 0 0 | 완료 결과 없음 | 서버 → 모두 | 대기 및 새 판 진행 중 | 이전 결과 삭제 |
| 안내 | /NOTICE | /NOTICE 본문 | /NOTICE 새 판 시작 | 사람이 읽는 안내 | 서버 → 모두 | 게임 진행 중 | 채팅 안내 표시 |
| 오류 | /ERROR | /ERROR 이유 | /ERROR 현재 본인의 차례가 아닙니다. | 요청 거절 이유 | 서버 → 요청자 | 잘못된 요청 | 안내와 최신 상태 확인 |

종료 전용 QUIT·BYE·ACK는 없습니다. 소켓을 닫으면 서버가 EOF로 퇴장을 처리합니다.

## STATE 필드

```text
/STATE revision hostId dealerId smallBlindId bigBlindId phase turnId pot currentBet minRaise count player... board
player = id,nickname,chips,bet,status
board = 카드코드를 쉼표로 연결하거나 없으면 -
```

```text
/STATE 3 1 1 1 2 PREFLOP 1 30 20 20 2 1,준석,990,10,PLAY 2,신현,980,20,PLAY -
```

status는 PLAY, FOLD, WAIT, LEFT입니다. phase는 WAITING, PREFLOP, FLOP, TURN, RIVER, SHOWDOWN, FINISHED입니다.
4주차의 SHOWDOWN은 족보 정산 완료, FINISHED는 폴드 승리 정산 완료입니다. 완료 단계의 pot과 turnId는 0입니다.
chips에는 이미 지급된 칩이 반영되어 있습니다. 클라이언트에서 결과 지급액을 다시 더하지 않습니다.

## RESULT 필드

```text
/RESULT handNumber type totalPot count entry...
entry = id,nickname,category,award,hand,bestFive
hand와 bestFive = 카드코드를 콜론으로 연결하거나 비공개이면 -
```

| 필드 | 의미 |
|---|---|
| handNumber | 새 판마다 증가하는 판 번호. NONE이면 0 |
| type | NONE, FOLD, SHOWDOWN |
| totalPot | 이번에 분배한 전체 판돈. 현재 STATE의 pot과 다름 |
| category | 0~9 족보 번호. 폴드 승리는 -1. code_guide.md 참고 |
| award | 판돈에서 받은 금액. 패배자는 0 |
| hand | 쇼다운까지 남은 참가자의 개인 카드 2장 |
| bestFive | 비교에 사용한 최상위 카드 5장 |

다음은 형식 설명용 예시입니다. 공용 카드가 스페이드 A·K·Q·J·10이면 두 사람 모두 같은 로열 플러시를 사용합니다.

```text
/RESULT 1 SHOWDOWN 40 2 1,준석,9,20,H2:D3,S14:S13:S12:S11:S10 2,신현,9,20,C4:H5,S14:S13:S12:S11:S10
```

쇼다운은 폴드하지 않은 참가자만 포함합니다. 폴드 승리는 승자와 지급액만 넣고 카드는 `-,-`입니다.
완료 결과는 다음 판 전까지 보관하므로 늦게 접속한 참가자도 동일한 결과를 받습니다.
같은 결과를 전송할 때 재정산하지 않으며, 클라이언트도 표시만 합니다.

## 전송과 검증

각 참가자에게 STATE → HAND → RESULT 순서로 전송한 뒤 NOTICE를 전달합니다.
동일한 GameTable 잠금 안에서 계산과 전송을 처리해 다른 행동의 상태가 끼어들지 않게 합니다.
행동하는 사람은 소켓에 등록된 참가자입니다. 클라이언트가 승자나 지급액을 지정하는 명령은 받지 않습니다.
START와 ACTION의 revision은 현재 상태번호와 같아야 합니다. 중복·오래된 요청은 거절합니다.
올인 명령과 사이드팟 정보는 5주차에 정의할 예정이며 이번 메시지에는 없습니다.
