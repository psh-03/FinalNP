import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 5~7장에서 가장 높은 5장 족보를 찾는다. 담당: 표신현
 * 7장 중 5장을 뽑는 경우는 21개뿐이다. 각 조합을 검사해 가장 큰 값을 고른다.
 * 무늬는 플러시 확인에만 사용하며 같은 족보의 우열을 정하지 않는다.
 */
public final class HandEvaluator {
    private HandEvaluator() { }
    private static final String[] NAMES = {"하이 카드", "원페어", "투페어", "트리플", "스트레이트",
            "플러시", "풀하우스", "포카드", "스트레이트 플러시", "로열 플러시"};

    // category가 우선이고, 같으면 비교용 숫자(kickers)를 앞에서부터 비교한다.
    // 예: 원페어 [12, 14, 9, 6] = Q 페어와 A, 9, 6 키커.
    public record Value(int category, List<Integer> kickers, List<Card> cards)
            implements Comparable<Value> {
        public Value {
            kickers = List.copyOf(kickers);
            cards = List.copyOf(cards);
        }
        @Override public int compareTo(Value other) {
            int comparison = Integer.compare(category, other.category);
            if (comparison != 0) { return comparison; }
            for (int i = 0; i < kickers.size(); i++) {
                comparison = Integer.compare(kickers.get(i), other.kickers.get(i));
                if (comparison != 0) { return comparison; }
            }
            return 0; // 비교에 쓰이는 5장이 같으면 무승부다.
        }
        public String name() { return categoryName(category); }
    }

    public static String categoryName(int category) {
        if (category == -1) { return "폴드 승리"; }
        if (category < 0 || category >= NAMES.length) { throw new IllegalArgumentException("족보 번호 오류"); }
        return NAMES[category];
    }

    public static Value evaluate(List<Card> cards) {
        if (cards.size() < 5 || cards.size() > 7) { throw new IllegalArgumentException("카드는 5~7장이어야 합니다."); }
        Set<String> unique = new HashSet<>();
        for (Card card : cards) {
            if (!unique.add(card.toWire())) { throw new IllegalArgumentException("중복 카드입니다."); }
        }
        Value best = null;
        int n = cards.size();
        // 서로 다른 인덱스 5개를 오름차순으로 선택하므로 중복 조합이 없다.
        for (int a = 0; a < n - 4; a++) {
            for (int b = a + 1; b < n - 3; b++) {
                for (int c = b + 1; c < n - 2; c++) {
                    for (int d = c + 1; d < n - 1; d++) {
                        for (int e = d + 1; e < n; e++) {
                            Value value = evaluateFive(List.of(cards.get(a), cards.get(b), cards.get(c), cards.get(d), cards.get(e)));
                            if (best == null || value.compareTo(best) > 0) { best = value; }
                        }
                    }
                }
            }
        }
        return best;
    }

    // evaluate()가 고른 5장 하나를 판정한다. 큰 족보부터 확인해야 서로 겹치지 않는다.
    private static Value evaluateFive(List<Card> hand) {
        List<Card> sorted = new ArrayList<>(hand);
        sorted.sort(Comparator.comparingInt(Card::getRank).reversed());
        int[] counts = new int[15];
        boolean flush = true;
        for (Card card : sorted) {
            counts[card.getRank()]++;
            if (card.getSuit() != sorted.get(0).getSuit()) { flush = false; }
        }
        List<Integer> ranks = new ArrayList<>();
        for (int rank = 14; rank >= 2; rank--) { if (counts[rank] > 0) { ranks.add(rank); } }
        int straightHigh = 0;
        if (ranks.size() == 5) {
            if (ranks.get(0) - ranks.get(4) == 4) { straightHigh = ranks.get(0); }
            else if (ranks.equals(List.of(14, 5, 4, 3, 2))) { straightHigh = 5; } // A는 여기서만 1
        }
        // 같은 숫자가 많은 순서, 그다음 숫자가 높은 순서로 정렬한다.
        List<Integer> groups = new ArrayList<>(ranks);
        groups.sort(Comparator.<Integer>comparingInt(r -> counts[r]).reversed()
                .thenComparing(Comparator.reverseOrder()));
        int first = counts[groups.get(0)];
        int second = groups.size() > 1 ? counts[groups.get(1)] : 0;
        if (flush && straightHigh > 0) {
            return new Value(straightHigh == 14 ? 9 : 8, List.of(straightHigh), sorted);
        }
        if (first == 4) { return new Value(7, groups, sorted); }
        if (first == 3 && second == 2) { return new Value(6, groups, sorted); }
        if (flush) { return new Value(5, ranks, sorted); }
        if (straightHigh > 0) { return new Value(4, List.of(straightHigh), sorted); }
        if (first == 3) { return new Value(3, groups, sorted); }
        if (first == 2 && second == 2) { return new Value(2, groups, sorted); }
        if (first == 2) { return new Value(1, groups, sorted); }
        return new Value(0, ranks, sorted);
    }
}
