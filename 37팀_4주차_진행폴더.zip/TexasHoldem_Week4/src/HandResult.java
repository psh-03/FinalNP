import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/** 한 판의 정산 결과와 통신 형식. 담당: 송준석, 게임 결과 연결: 표신현
 * 클라이언트는 이 값을 표시할 뿐 칩을 지급하거나 승자를 다시 계산하지 않는다.
 */
public record HandResult(long handNumber, String type, int totalPot, List<Entry> entries) {
    public record Entry(int id, String nickname, int category, int award,
            List<Card> hand, List<Card> bestFive) {
        public Entry { hand = List.copyOf(hand); bestFive = List.copyOf(bestFive); }
    }
    public HandResult { entries = List.copyOf(entries); }
    public static HandResult empty() { return new HandResult(0, "NONE", 0, List.of()); }

    // 참가자 사이에는 공백, 한 참가자의 필드 사이는 쉼표, 카드 사이는 콜론을 쓴다.
    public String toWire() {
        StringBuilder line = new StringBuilder("/RESULT ");
        line.append(handNumber).append(' ').append(type).append(' ').append(totalPot).append(' ').append(entries.size());
        for (Entry entry : entries) {
            line.append(' ').append(entry.id()).append(',').append(entry.nickname()).append(',')
                    .append(entry.category()).append(',').append(entry.award()).append(',')
                    .append(cardsToWire(entry.hand())).append(',').append(cardsToWire(entry.bestFive()));
        }
        return line.toString();
    }
    private static String cardsToWire(List<Card> cards) {
        return cards.isEmpty() ? "-" : cards.stream().map(Card::toWire).collect(Collectors.joining(":"));
    }
    private static List<Card> parseCards(String text) {
        List<Card> cards = new ArrayList<>();
        if (!text.equals("-")) { for (String code : text.split(":")) { cards.add(Card.fromWire(code)); } }
        return cards;
    }
    public static HandResult parse(String line) {
        String[] f = line.split(" ");
        if (f.length < 5 || !f[0].equals("/RESULT")) { throw new IllegalArgumentException("결과 형식 오류"); }
        long number = Long.parseLong(f[1]);
        String type = f[2];
        int pot = Integer.parseInt(f[3]), count = Integer.parseInt(f[4]);
        if (number < 0 || pot < 0 || count < 0 || count > 6 || f.length != 5 + count
                || !List.of("NONE", "FOLD", "SHOWDOWN").contains(type)) {
            throw new IllegalArgumentException("결과 값 오류");
        }
        List<Entry> entries = new ArrayList<>();
        long paid = 0;
        for (int i = 0; i < count; i++) {
            String[] p = f[5 + i].split(",");
            if (p.length != 6) { throw new IllegalArgumentException("결과 참가자 형식 오류"); }
            int id = Integer.parseInt(p[0]), category = Integer.parseInt(p[2]), award = Integer.parseInt(p[3]);
            List<Card> hand = parseCards(p[4]), best = parseCards(p[5]);
            if (id <= 0 || award < 0 || (type.equals("SHOWDOWN")
                    ? category < 0 || category > 9 || hand.size() != 2 || best.size() != 5
                    : category != -1 || !hand.isEmpty() || !best.isEmpty())) {
                throw new IllegalArgumentException("결과 카드 또는 지급액 오류");
            }
            paid += award;
            entries.add(new Entry(id, p[1], category, award, hand, best));
        }
        if (paid != pot || (type.equals("NONE") && (number != 0 || count != 0 || pot != 0))
                || (type.equals("FOLD") && count != 1) || (type.equals("SHOWDOWN") && count < 2)) {
            throw new IllegalArgumentException("정산 합계 오류");
        }
        return new HandResult(number, type, pot, entries);
    }
}
