@echo off
title Holdem Week4 Server
chcp 949 >nul
cd /d "%~dp0"
java -jar dist\week4-server.jar %*
pause
