"""실제 JAR 서버에 TCP 클라이언트를 연결하는 선택 실행 검사. Python 3 표준 라이브러리만 사용."""
from pathlib import Path
import json, socket, subprocess, threading, time

ROOT = Path(__file__).resolve().parents[1]
RESULTS = []

def check(ok, name):
    if not ok: raise AssertionError(name)
    RESULTS.append({"test": name, "result": "PASS"})

def parse(line):
    f = line.split(" "); count = int(f[11])
    players = {}
    for value in f[12:12+count]:
        p = value.split(",")
        players[int(p[0])] = dict(name=p[1], chips=int(p[2]), bet=int(p[3]), status=p[4])
    return dict(raw=line, rev=int(f[1]), host=int(f[2]), dealer=int(f[3]), sb=int(f[4]), bb=int(f[5]),
                phase=f[6], turn=int(f[7]), pot=int(f[8]), current=int(f[9]), minimum=int(f[10]),
                players=players, board=[] if f[-1] == "-" else f[-1].split(","))

class Peer:
    def __init__(self, port, name):
        self.socket = socket.create_connection(("127.0.0.1", port), timeout=3)
        self.socket.settimeout(None)
        self.lines = []; self.condition = threading.Condition()
        self.reader = threading.Thread(target=self.receive, daemon=True); self.reader.start()
        self.send("/JOIN " + name)
    def receive(self):
        try:
            with self.socket.makefile("r", encoding="utf-8") as reader:
                for line in reader:
                    with self.condition:
                        self.lines.append(line.rstrip("\n")); self.condition.notify_all()
        except OSError: pass
    def send(self, line): self.socket.sendall((line + "\n").encode("utf-8"))
    def wait(self, predicate, start=0):
        deadline = time.monotonic() + 5
        with self.condition:
            while True:
                for line in self.lines[start:]:
                    if predicate(line): return line
                left = deadline - time.monotonic()
                if left <= 0: raise AssertionError("메시지 대기 시간 초과: " + repr(self.lines[-8:]))
                self.condition.wait(left)
    def state(self): return parse(next(x for x in reversed(self.lines) if x.startswith("/STATE ")))
    def sync(self, rev):
        self.wait(lambda x: x.startswith("/STATE ") and parse(x)["rev"] >= rev)
        return self.state()
    def join(self):
        self.id = int(self.wait(lambda x: x.startswith("/JOIN_OK ")).split()[1])
        self.wait(lambda x: x.startswith("/STATE "))
        return self
    def close(self):
        try: self.socket.shutdown(socket.SHUT_RDWR)
        except OSError: pass
        self.socket.close(); self.reader.join(timeout=1)

def rejected(p, command, name):
    before = p.state(); mark = len(p.lines)
    p.send(command)
    p.wait(lambda x: x.startswith("/ERROR "), mark)
    p.wait(lambda x: x.startswith("/STATE "), mark)
    check(p.state()["raw"] == before["raw"], name)

def move(p, action, amount=None, all_peers=()):
    s = p.state(); p.send(f'/ACTION {s["rev"]} {action}' + ("" if amount is None else " " + str(amount)))
    p.sync(s["rev"] + 1)
    for peer in all_peers: peer.sync(s["rev"] + 1)
    return p.state()

def run(port):
    peers=[]
    def new(name):
        p=Peer(port,name); peers.append(p); return p
    try:
        a=new("준석").join()
        rejected(a, f'/START {a.state()["rev"]}', "한 명일 때 시작 거절")
        b=new("신현").join(); a.sync(b.state()["rev"])
        duplicate=new("준석")
        check(duplicate.wait(lambda x:x.startswith("/ERROR ")) is not None, "중복 닉네임 거절")
        duplicate.close()
        invalid=new("bad name")
        check(invalid.wait(lambda x:x.startswith("/ERROR ")) is not None, "잘못된 닉네임 거절")
        invalid.close()
        a.send("/CHAT 한글  채팅 확인")
        expected="/CHAT 준석 한글  채팅 확인"
        check(a.wait(lambda x:x==expected)==b.wait(lambda x:x==expected), "한글과 중간 공백 유지")
        rejected(b, f'/START {b.state()["rev"]}', "방장 외 시작 거절")
        old=a.state()["rev"]; a.send(f"/START {old}"); a.sync(old+1); b.sync(old+1)
        s=a.state()
        check(s["raw"]==b.state()["raw"] and s["pot"]==30 and s["turn"]==a.id, "블라인드와 첫 차례 동기화")
        ha=a.wait(lambda x:x.startswith("/HAND ")).split()[1:]
        hb=b.wait(lambda x:x.startswith("/HAND ")).split()[1:]
        check(len(set(ha+hb))==4, "서로 다른 개인 카드 네 장")
        check(not any(x in s["raw"].split() for x in ha+hb), "공개 상태에 개인 카드 미포함")
        rejected(a,f'/START {s["rev"]}',"진행 중 재시작 거절")
        rejected(b,f'/ACTION {s["rev"]} FOLD',"다른 사람 차례 거절")
        rejected(a,f'/ACTION {s["rev"]} CHECK',"콜 금액이 있는 체크 거절")
        rejected(a,f'/ACTION {s["rev"]} RAISE 39',"최소 레이즈 미만 거절")
        rejected(a,f'/ACTION {s["rev"]} RAISE 1000',"올인 요청 거절")
        rejected(a,f'/ACTION {s["rev"]} RAISE 999999999999999',"정수 범위 초과 입력 거절")
        mark=len(a.lines)
        a.send(f'/ACTION {s["rev"]} CALL'); a.send(f'/ACTION {s["rev"]} CALL')
        a.sync(s["rev"]+1); b.sync(s["rev"]+1)
        a.wait(lambda x:x.startswith("/ERROR "),mark)
        check(a.state()["pot"]==40 and a.state()["turn"]==b.id,"중복 요청 한 번만 처리 및 BB 차례 유지")
        s=move(b,"CHECK",all_peers=[a]); check(s["phase"]=="FLOP" and len(s["board"])==3,"플롭 세 장 공개")
        s=move(b,"BET",20,[a]); s=move(a,"RAISE",60,[b]); s=move(b,"CALL",all_peers=[a])
        check(s["phase"]=="TURN" and len(s["board"])==4 and s["pot"]==160,"베트 레이즈 콜 뒤 턴 전환")
        for phase,size in [("RIVER",5),("SHOWDOWN",5)]:
            move(b,"CHECK",all_peers=[a]); s=move(a,"CHECK",all_peers=[b])
            check(s["phase"]==phase and len(s["board"])==size,phase+" 단계 동기화")
        check(a.state()["raw"]==b.state()["raw"] and s["pot"]==160,"리버 종료 후 임의 승자 없이 판돈 보관")
        check(len(set(ha+hb+s["board"]))==9,"개인 카드와 공용 카드 중복 없음")
        rejected(a,f'/ACTION {s["rev"]} CHECK',"판정 대기에서 추가 행동 거절")
        rev=s["rev"]; a.send(f'/START {rev}'); a.sync(rev+1); b.sync(rev+1)
        s=a.state()
        check(s["players"][a.id]["chips"]==980 and s["players"][b.id]["chips"]==990 and s["dealer"]==b.id,"미정산액 반환과 딜러 이동")
        s=move(b,"FOLD",all_peers=[a]); check(s["phase"]=="FINISHED" and s["players"][a.id]["chips"]==1010 and s["pot"]==0,"폴드 승리 칩 지급")
        rev=s["rev"]; a.send(f'/START {rev}'); a.sync(rev+1); b.sync(rev+1)
        before=a.state(); c=new("참관자").join(); a.sync(c.state()["rev"]); b.sync(c.state()["rev"])
        s=a.state()
        check(s["phase"]==before["phase"] and s["pot"]==before["pot"] and s["players"][c.id]["status"]=="WAIT","중도 접속은 판을 초기화하지 않음")
        check(c.wait(lambda x:x=="/HAND")=="/HAND","대기자에게 개인 카드 미전송")
        rejected(a,f'/ACTION {before["rev"]} CALL',"오래된 화면 상태의 요청 거절")
        turn=s["turn"]; actor=a if turn==a.id else b; survivor=b if actor is a else a
        actor.close(); survivor.sync(s["rev"]+1); c.sync(s["rev"]+1)
        check(survivor.state()["phase"]=="FINISHED" and survivor.state()["host"]==survivor.id,"차례 참가자 퇴장 시 폴드와 방장 유지 또는 이전")
        rev=survivor.state()["rev"]; survivor.send(f'/START {rev}'); survivor.sync(rev+1); c.sync(rev+1)
        check(c.state()["players"][c.id]["status"]=="PLAY" and len(c.state()["players"])==2,"대기자의 다음 판 참가")
        check(not any(x.startswith(("WELCOME","ACK","BYE")) for x in a.lines+b.lines+c.lines),"불필요한 확인 메시지 없음")
        (ROOT/'evidence/two_client_protocol.txt').write_text("\n".join(a.lines),encoding="utf-8")
    finally:
        for p in peers: p.close()

if __name__ == '__main__':
    (ROOT/'evidence').mkdir(exist_ok=True)
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]
    with (ROOT/'evidence/server_test.log').open('w',encoding='utf-8') as log:
        server=subprocess.Popen(['java','-jar',str(ROOT/'dist/week3-server.jar'),str(port)],stdout=log,stderr=log)
        try:
            for _ in range(100):
                if server.poll() is not None: raise AssertionError('서버 실행 실패')
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.2): break
                except OSError: time.sleep(.05)
            else: raise AssertionError('서버 준비 시간 초과')
            run(port)
        finally:
            server.terminate(); server.wait(timeout=5)
    (ROOT/'evidence/network_results.json').write_text(json.dumps({'environment':'실제 JAR 서버와 TCP 클라이언트, UTF-8','tests':RESULTS},ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS',len(RESULTS),'TCP integration checks')
