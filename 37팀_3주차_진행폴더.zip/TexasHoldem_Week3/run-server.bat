@echo off
title Holdem Week3 Server
chcp 949 >nul
cd /d "%~dp0"
java -jar dist\week3-server.jar %*
pause
