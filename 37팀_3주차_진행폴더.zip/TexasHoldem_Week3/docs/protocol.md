# 3주차 응용 계층 프로토콜

TCP, UTF-8, 줄바꿈 한 개로 메시지 한 개를 구분합니다. 기본 포트는 5555입니다.
닉네임에는 공백과 쉼표가 들어갈 수 없습니다. 채팅은 명령 다음 문자열 전체를 읽습니다.

| 기능 | 프로토콜 | 프로토콜 형식 | 실제 예시 | 각 값의 의미 | 전송 방향 | 전송 시점 | 수신 후 처리 |
|---|---|---|---|---|---|---|---|
| 참가 요청 | /JOIN | /JOIN 닉네임 | /JOIN 준석 | 닉네임 | 클라이언트 → 서버 | 접속 직후 | 중복·정원 검사 후 ID 등록 |
| 참가 승인 | /JOIN_OK | /JOIN_OK ID | /JOIN_OK 1 | 내 ID | 서버 → 요청자 | 등록 성공 | 내 ID 저장 |
| 채팅 요청 | /CHAT | /CHAT 내용 | /CHAT 안녕하세요 | 내용 1~200자 | 클라이언트 → 서버 | 전송 버튼 | 소켓에 등록된 닉네임을 붙여 전달 |
| 채팅 전달 | /CHAT | /CHAT 닉네임 내용 | /CHAT 준석 안녕하세요 | 실제 송신자와 내용 | 서버 → 전체 | 채팅 수신 | 채팅창에 한 번 표시 |
| 판 시작 | /START | /START revision | /START 2 | 클라이언트가 본 상태 번호 | 클라이언트 → 서버 | 방장 시작 버튼 | 번호·방장·인원·진행 여부 검사 |
| 기본 행동 | /ACTION | /ACTION revision CHECK 또는 CALL 또는 FOLD | /ACTION 3 CALL | 상태 번호와 행동 | 클라이언트 → 서버 | 현재 차례의 버튼 | 차례와 행동 가능 여부 검사 |
| 금액 행동 | /ACTION | /ACTION revision BET 또는 RAISE 총액 | /ACTION 5 RAISE 60 | 이번 단계에서 맞출 총액 | 클라이언트 → 서버 | 베트·레이즈 버튼 | 최소 금액·잔액 검사 후 반영 |
| 공개 상태 | /STATE | 아래 전체 형식 참고 | 아래 예시 참고 | 차례·판돈·공용 카드 등 | 서버 → 전체 또는 요청자 | 입장·퇴장·시작·행동·오류 복구 | 한 번에 화면 상태 갱신 |
| 개인 카드 | /HAND | /HAND 카드1 카드2 | /HAND S14 H12 | 해당 참가자의 카드 | 서버 → 본인 | 상태 전송 직후 | 손패 표시. /HAND만 오면 지움 |
| 게임 안내 | /NOTICE | /NOTICE 내용 | /NOTICE 준석: 콜 10 | 행동과 단계 안내 | 서버 → 전체 | 게임 상태 변화 | 채팅 안내 영역에 표시 |
| 요청 오류 | /ERROR | /ERROR 이유 | /ERROR 현재 본인의 차례가 아닙니다. | 거절 이유 | 서버 → 요청자 | 잘못된 요청 | 안내 표시, 행동 요청 오류는 최신 상태도 수신 |

## 공개 상태 형식

```text
/STATE revision hostId dealerId smallBlindId bigBlindId phase turnId pot currentBet minRaise count player... board
player = id,nickname,chips,bet,status
board  = - 또는 쉼표로 연결한 카드 코드
```

두 명이 처음 시작한 직후의 예시:

```text
/STATE 3 1 1 1 2 PREFLOP 1 30 20 20 2 1,준석,990,10,PLAY 2,신현,980,20,PLAY -
```

| 필드 | 뜻 |
|---|---|
| revision | 공개 상태 변경 번호. 요청의 번호가 오래되면 거절 |
| hostId / dealerId | 방장 ID / 딜러 자리 ID. 서로 다른 개념 |
| smallBlindId / bigBlindId | 이번 판 블라인드 자리 |
| phase | WAITING, PREFLOP, FLOP, TURN, RIVER, SHOWDOWN, FINISHED |
| turnId | 행동할 참가자. 0이면 행동 차례 없음 |
| pot / currentBet / minRaise | 전체 판돈 / 이번 단계 최고 총액 / 최소 인상분 |
| count | 표시할 자리 수. 현재 판 기록을 유지하는 퇴장자도 포함 |
| status | PLAY 참여, FOLD 폴드, WAIT 다음 판 대기, LEFT 퇴장 |
| board | 공개된 공용 카드만 포함. 개인 카드는 절대 포함하지 않음 |

예를 들어 S14는 스페이드 A, H12는 하트 Q입니다.
진행 중 합류한 사람은 WAIT이며 /HAND는 빈 손패로 전달합니다. 현재 판은 유지합니다.
퇴장은 소켓 종료로 감지합니다. WELCOME/ACK/BYE나 별도 QUIT 명령은 없습니다.

`/TABLE`은 3주차에서 `/STATE`로 바뀌었고 `/START`에는 revision이 추가되었습니다.
따라서 2주차 클라이언트와 혼합해서 실행하지 않습니다.
